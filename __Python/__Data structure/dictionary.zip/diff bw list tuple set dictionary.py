diff b/W List,Tuple,Set,Dictionary

List                  Tuple                set                  Dictionary
1. represented as []  1.represented as () 1.represented as {}   1.represented as {(k:v)}
2. mutable object     2.Immutabe object   2.Mutable object      2.mutable object
3. elements can be    3.elements can be   3.elements should     3.elements can be 
   mutable/immutable    mutable/immutable   be immutable          mutable/immuable
4.duplicates allowed  4.duplicates allowed 4.not allowed        4.duplicate keys are
                                                                  not allowed,values are
                                                                  allowed.
5.created using list() 5.created using     5.using set()        5.created using dict()
                         tuple()
