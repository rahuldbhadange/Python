#modifying,adding and printing an element of dictionary
std={"name":"kumar","height":5.6,"weight":75}
print(std)
print(std["name"])  #value of the key will be printed
#modifying the weight
std["weight"]=80
print("after modifying \n",std)
#adding new elements into dictionary
std["age"]=28
std["branch"]="CSE"
print("after adding:\n",std)
