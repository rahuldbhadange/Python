# creating dictionary elements

x={"sachin":95,"Ganguly":65,"Dravid":35}  # homogeneous keys(string type),homogeneous values(int type)
print(x)
print(type(x))
print(len(x))

y={"height":5.5,1:"male",2.99:3} #heterogeneous keys and heterogeneous values
print(y)
print(type(y))
print(len(y))

z={"CSE":120,"ECE":90,"IT":60,"EEE":60,"CSE":60} #duplicate keys are not allowed,but values are allowed.
print(z)
print(type(z))
print(len(z))

a={ }  #empty dictionary
print(a)
print(type(a))
print(len(a))

b=dict() #empty dictionary
print(b)
print(type(b))
print(len(b))

c=dict( )
d={"rank":15}
c=d
print(c)
print(d)
print(type(c))
print(len(c))

