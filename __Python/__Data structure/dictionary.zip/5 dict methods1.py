
#getting keys and values
material={"books":10,"pens":20,"chairs":30}
print(material.keys())  #prints all keys
print(material.values()) #prints all values



