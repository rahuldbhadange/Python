Dictionary: Dictionary is a collection datatype which holds group of (key,value)
pairs

Properties of Dictionary:

1.Dictionary represented by curly braces { }
2.keys and values can be homogeneous or heterogeneous
3.keys cannot be duplicated,but values can be duplicated.  ex: age=60 & wt=60  
4.Insertion order is not preserved.
5.Dictionary is a mutable object.
6.Dictionary can be created directly by using { } or by using dict() function

