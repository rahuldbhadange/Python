#dictionary is used for collection of vaious details(k,V)pairs about a particular object.
#ex: customer,employee,student,etc

customer={"name":"Ajay","AccNo":30129684561,"Branch":"Ameerpet","type":"savings"}
employee={"name":"vijay","sal":70000,"Desig":"manager","Branch":"Ameerpet"}
student={"name":"pranay","branch":"CSE","college":"JNTU","Loc":"kukatpally"}
print(customer)
print(employee)
print(student)
#Accessing elements of dictionary using key
print(customer["name"])
print(employee["name"])
print(student["name"])
print(student["college"])
print(employee["sal"])
