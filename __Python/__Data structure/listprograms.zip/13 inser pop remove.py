#insert(),pop(),remove() methods
x=[501,6.1,True,"python"]
print(x)
x.insert(2,60) #inserts 60 at index 2
print(x)
x.pop(3)       #removes element at index 3
print(x)
x.remove("python") #removes element "python"
print(x)

#diff b/w pop and remove is---
#pop() removes element present at a given index but,
#remove() removes a particular element without index.


