#Functions which can be applied on lists
#ex:- len(),max(),min(),sorted(),reversed()

x=[60,10,40,30,20,50]
print(len(x))
print(sum(x))
print(max(x))
print(min(x))
print(sorted(x))




print(reversed(x)) #stored in another object and returns its address
for p in reversed(x): # printing each element of the object
    print(p)

print("\n")
for p in reversed(sorted(x)):  #first sorted()fn executes and then reversed
    print(p)

# max,min,len,sort------>applied on homogeneous elements.
