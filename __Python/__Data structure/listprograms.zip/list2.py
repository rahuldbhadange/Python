x=[1,2,3,4,5]

y=[1,2,3,4,5]

print(x,id(x))
print(y,id(y))

print(x[0],id(x[0]))
print(y[0],id(y[0]))
