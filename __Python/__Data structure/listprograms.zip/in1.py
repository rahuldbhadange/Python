#in operator   l
#performing sum of list elements using for loop and while loop
x=[10,20,30,40,50]
sum=0
for p in x:
    sum=sum+p
print(sum)


#II-way(using while loop)
i=0
sum1=0
while(i<len(x)):
    sum1=sum1+x[i]
    i=i+1
print(sum1)

