x=10
y=10
print(x,id(x))
print(y,id(y))

In fundamental datatypes if content is same ,then only one object is created
and its address is returned to both the variables.

In collection datatypes, if content is same,then 2 different objects are created
with 2 different addresses

a=[1,2,3,4,5]
 
b=[1,2,3,4,5]

print(a,id(a))

print(b,id(b))

