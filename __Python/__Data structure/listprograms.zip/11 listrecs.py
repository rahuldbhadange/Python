# nested lists, storing emp records
x=[[101,"scott",10000],[102,"miller",20000],[103,"Blake",30000]]
#here each list storing a record
#Task:implementing empnames in sorted order

#first verfify whether empname is available in same position in every list
#then copy all empnames of each list into another list and perform sorted
#for copying from one list to another we have a function called append()

for p in x:
    print(p)
names=[]   #creating empty list
#now adding names from list x to list names using append()
print("extracting only names")
for a in x:
    names.append(a[1]) #appending only names not eid or salaries 
print(names)
print("printing in sortd order")
print(sorted(names))
