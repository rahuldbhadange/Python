List:List is a collection datatype which holds group of values
Properties of List:

1.List represented by square bracket[  ]
2.List allows homogeneous elements.  ex;  x=[10,20,30,40,50]

3.List allows heterogeneous elements. ex: x=[50,6.1,True,"hello"]

4.List allows duplicate elements      ex: x=[10,20,30,10,20,40]

5.In List, insertion order is  preserved,the order in which the elements are
  inserted and the order in which they are stored are same.
  
6.Every element of List is identified by a unique index.
  List supports positive and negative index.
  positive index starts from leftside
  negative index starts from rightside
  positive index starts from 0
  negative index starts from -1
   ex: x=[10,20,30,40,50]
         x[0]=10           x[4]=50   #positive indexes
         x[-1]=50          x[-3]=30  #negative indexes
         x[2:]=(30,40,50)  x[1:4]=(20,30,40)   x[-4:-1]=(20,30,40) #slice operator
         x[4:1]=()      x[-1:-4]=()
         
7.List is a mutable object(means elements of list can be changed or modified)
      ex:  x=[10,20,30,40,50]
             x[2]=60   modifying the 3rd element i.e 30 to 60
             
8.List can be created directly by using [ ] or by using list() function

