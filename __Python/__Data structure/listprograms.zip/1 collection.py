#      COLLECTION DATA TYPES

#There r 2 types of Datatypes
#1. Fundamental Data types: Objects holding single value
#  ex:- Int,Float,Bool,Str
#  ex:- x=10 (object x holding sigle value(Int) i.e 10)

#2.Collection Datatypes: Objects holding group of values
#  ex:- Lists,Tuples,sets,Dictionaries
# ex;- x=[10,20,30,40,50] (object x is holding group of values)

# There r 4 types of collections in Python
#1.List
#2.Tuple
#3.Set
#4.Dictionary
