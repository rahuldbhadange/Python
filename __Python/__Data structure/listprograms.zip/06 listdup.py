#List with duplicates
x=[10,20,30,40,50,10,20,30]
print(x,type(x),id(x))
print(len(x))
for p in x:
    print(p,type(p),id(p))
