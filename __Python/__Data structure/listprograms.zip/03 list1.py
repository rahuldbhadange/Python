# program illustrating list
x=[10,20,30,40,50]
print(x)           #printing list elements
print(type(x))
print(id(x))

print(x[0])        #printing 1st element of list
print(type(x[0]))
print(id(x[0]))

print(x[1])        #printing 2nd element of list
print(type(x[1]))
print(id(x[1]))

