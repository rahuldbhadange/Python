#modying elements of lists is allowed(mutable)

x=[[10,20,30],[40,50,60],[70,80,90]]
print(x,type(x))

x[0]=10
x[1]="python"
x[2]=22.5
print("\nLIST AFTER MODIFICATION:")
print(x,type(x))
print("\nEACH ELEMENT OF LIST IS:")
print(x[0],type(x[0])) 
print(x[1],type(x[1])) 
print(x[2],type(x[2])) 
