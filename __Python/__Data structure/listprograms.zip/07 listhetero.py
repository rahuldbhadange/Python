#list with heterogeneous elements
x=[501,6.1,True,"python"]
print(x[2])
print(x[3][2])
for p in x:
print(p,type(p),id(p))

    
