#Accessing List elements and slice operator
x=[10,20,30,40,50]
print(x)
print(x[0])
print(x[1])
print(x[-3])
print(x[1:4])
print(x[-5:-1])
print(x[4:1])   #empty list will be displayed 
print(x[-1:-5]) #empty list will be displayed
print(x[1: ])
print(x[ :4])
print(x[ : ])
print(x)
