#Applying for loop on list
#printing list elements using for loop
x=[10,20,30,40,50]
print(x)
print("printing each element of list:")
for p in x:
    print(p) #printing each element of list


    

print("printing each element of list in a line :")
for p in x:
    print(p,end=' ')

