#List methods

#appending,removing and extending elements of the list

x=[10,20,30,40,50]
print(x)
print(id(x))


x.append(60) #adding a new element to the list
print("After adding,new list is:")
print(x)
print(id(x))

x.remove(20)  #removing an element from the list
print("after removing 20")
print(x)
print(id(x))

y=[1.5,2.5,3.5,4.5,5.5]
x.extend(y)  #extending the list
print("after extending")
print(x)
print(id(x))
print(len(x))

print("sorted order is")
print(sorted(x))
print(id(x))
print("in all cases the address of list remains same")

