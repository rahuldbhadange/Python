#creating list using list()
x=list()  #creating empty list
print(x)
print(type(x))
print(len(x))

y=list("hadoop")  #creting list with data
print(y)
print(len(y))
print(id(y))

y[5]="b"    # modifying element of the list
print(y)
print(id(y))

#Note: list() fn accepts only one parameter,that too string type
'''z=list(10,20)  
print(z)
print(len(z))
print(id(z)) '''


