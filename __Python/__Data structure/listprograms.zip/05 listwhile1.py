#Applying while loop on list
x=[10,20,30,40,50]
i=0
while(i<5):
    print(x[i])
    i=i+1

#dynamically giving size value

x=[10,20,30,40,50]
i=0
while(i<len(x)):
    print(x[i])
    i=i+1






