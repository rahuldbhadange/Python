#searching for element using in operator

x=[10,20,30,40,50]
print(x)
s=int(input("enter search element"))
if(s in x):
    print("Element is found")
else:
    print("Element is not found")


#using heterogeneous elements
print("In heterogeneous list")
x=[501,6.1,True,'java']
print(501 in x)
print(1 in x)
print('java' not in x)
print(6.1 not in x)
