x=[[10,20,30],[40,50,60],[70,80,90]]
print(x)
print(type(x))
print(len(x))

print(x[0],type(x[0])) #1st list
print(x[1],type(x[1])) #2nd list
print(x[2],type(x[2])) #3rd list
print(x[1][2])
print(x[2][2])

#2) displaying  each list using for loop

for p in x: 
    print(p,type(p))

    
#3) for loop within for loop ---->for displaying each element of list
print("displaying each element of list")
for p in x:
    for q in p:
        print(q,type(q))

#nested list used for database tables
        #each row taken as one list.......
        #1st row-1st list
        #2nd row-2nd list and so on........
