SET:SET is a collection datatype which holds group of values

Properties of SET:

1.Set represented by curly braces {  }
2.Set allows homogeneous elements.  ex;  x={10,20,30,40,50}
3.Set allows heterogeneous elements. ex: x={501,6.1,True,"hello"}
4.Set doesn't allow duplicates           
5.In Set, insertion order is not preserved.
6.Set doesn't support indexing.
  we cannot access elements of set using index, print(x[1]) is invalid.
  we can access the elements using for loop,
  we cannot access using while loop also because while loop requires index.

7.Set is a mutable object, but elements of set should be immutable.
8.Set can be created directly by using { } or by using set() function
9.we can perform mathematical operations on set object.
  ex: max,min,len,sort------>applied on homogeneous elements.
