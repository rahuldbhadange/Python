#searching for an element in set
x={10,20,30,40,50}
print(x)

print(20 in x)
print(70 in x)

y={10,20,30,40,50}
print(y)
print(x is y)  
print(x==y)    

x={10,20,30,40,60}
print(x)
print(x is x)
print(x==x)

a={1,2,3,4,5}
print(a)

b={1,2,3,4,5}
print(b)
print(a is b)
print(a==b)


a,b,c,d,e=x
print(a,b,c,d,e)
