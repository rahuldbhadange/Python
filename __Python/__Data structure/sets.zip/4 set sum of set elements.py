#performing sum of set elements
x={10,20,30,40,50}
sum=0
for p in x:
    sum=sum+p
print("sum=",sum)
    
