#creating set object
x={10,20,30,40,50}  #homogeneous elements
print(x)
print(type(x))

y={501,6.1,True,"hello"} #heterogeneous elements
print(y)
print(type(y))
 
z={10,20,30,(40,50,60)}  # only immutable elements are allowed within set
print(z)
print(type(z))

a=set()           #creating empty set
print(a)
print(type(a))
print(len(a))

b=set("hello")    #creating set with data
print(b)          #only one parameter allowed witin set()
print(type(b))    #i.e string or iterable types
print(len(b))

m=set([10,20,30,40])    
print(m)          
print(type(m))  
print(len(m))

c={10,20,10,20,30} #duplicate elements will be eliminated
print(c)
print(len(c))

'''d={{10,20,30},{40,50,60},{70,80,90}} # sets within set are not allowed
print(d)'''
