#applying functions on set
x={10,20,30,40,50}
print(x)
print(type(x))
print(len(x))
print(sum(x))
print(max(x))
print(min(x))
print(sorted(x))
