#converting list to tuple,tuple to set
x=[10,20,30,40,50,10,20,30]
#x=[[10,20,30],40,50,10,20,30]  #can be converted into tuple but not to set
print(x)
print(tuple(x))
print(set(x)) # duplicates eliminated , insertion order not preserved
