# methods of set -----add(),copy(),update(),pop(),discard(),clear()
x={10,20,30,40,50}
print(x)
x.add(60)     #adding 60 to set
print("after adding:")
print(x)
y=x.copy()  #creates a copy of x
print("another copy :")
print(y)
x.update((50,60,70)) #updating the set
print(x)
x.pop()     #removes an element randomly
print(x)
x.discard(20) #removes particular element of our choice
print(x)
x.clear()  #clears all set elements
print(x)

