def __add_test_documents(self, event):
    existing = self._data_access.load(self.RON_DATA_TABLE, event.asset, query={"asset_id": event.asset,
                                                                               "Type": "SapTestDocumentSet"})
    if existing:
        return

    utc_time = pytz.utc.localize(event.time)
    iso_format = utc_time.isoformat()
    data_to_save = {
        "asset_id": event.asset,
        "Source": event.source,
        "Ts": iso_format,
        "Seq": event.offset,
        "Type": "SapTestDocumentSet",
        "Description": "Technical Document",
        "Details": [
            {
                "DocumentCount": 1,
                "DocumentId": "Station Acceptance Test"
            }
        ],
        "Attachments": [
            {
                "Name": "Station Acceptance Test",
                "Link": "test-document/{}/PPM".format(event.asset)
            }
        ]
    }

    self._data_access.save(self.RON_DATA_TABLE, event.asset, data_to_save)

    data_to_save = {
        "asset_id": event.asset,
        "Source": event.source,
        "Ts": iso_format,
        "Seq": event.offset,
        "Type": "SapTestDocumentSet",
        "Description": "Technical Document",
        "Details": [
            {
                "DocumentCount": 1,
                "DocumentId": "Test Bench"
            }
        ],
        "Attachments": [
            {
                "Name": "Test Bench",
                "Link": "test-document/{}/MOA".format(event.asset)
            }
        ]
    }

    self._data_access.save(self.RON_DATA_TABLE, event.asset, data_to_save)

    data_to_save = {
        "asset_id": event.asset,
        "Source": event.source,
        "Ts": iso_format,
        "Seq": event.offset,
        "Type": "SapTestDocumentSet",
        "Description": "Technical Document",
        "Details": [
            {
                "DocumentCount": 1,
                "DocumentId": "Installation Report"
            }
        ],
        "Attachments": [
            {
                "Name": "Installation Report",
                "Link": "test-document/{}/IPR".format(event.asset)
            }
        ]
    }

    self._data_access.save(self.RON_DATA_TABLE, event.asset, data_to_save)
