@requires_auth
def get_document_by_type(asset_id, document_type):
    """Get document using document type.
    """
    follower = current_app.config['follower']
    first_chunk = None

    # if document_type == "MOA":
    #     file_name = "{}_test_bench.pdf".format(asset_id)
    # elif document_type == "PPM":
    #     file_name = "{}_station_acceptance.pdf".format(asset_id)

    try:
        iterator = iter(follower.request_sap_document_type(asset_id, document_type))
        mime_type, first_chunk = next(iterator)

        ext = mime_type.split("/")[1]

        if document_type == "MOA":
            file_name = "{}_test_bench.{}".format(asset_id, ext)
        elif document_type == "PPM":
            file_name = "{}_station_acceptance.{}".format(asset_id, ext)
        elif document_type == "IRP":
            file_name = "{}_installation_report.{}".format(asset_id, ext)

    except AssetUnknown:
        logger.warning('T2 - Asset %s no longer known, ignoring', asset_id)
        raise NotFound()
    except T2ResponseException as ex:
        if ex.reason == T2ReqFailureReason.REQ_UNHANDLED:
            logger.error('T2 request not handled by provider')
        elif ex.reason == T2ReqFailureReason.RESOURCE_UNKNOWN:
            logger.error('Data not available for given request and asset')
            raise NotFound()
        else:
            logger.error('T2 failed - reason: %s', ex.reason)
        raise InternalServerError({"code": "failed requesting document", "description": str(ex)}, status_code=500)
    except T2Unavailable as ex:
        msg = 'T2 functionality not enabled in follower'
        logger.critical(msg)
        raise InternalServerError({"code": msg, "description": str(ex)}, status_code=500)
    except T2Timeout as ex:
        msg = 'T2 request timed out'
        logger.error(msg)
        raise InternalServerError({"code": msg, "description": str(ex)}, status_code=500)
    except ShutdownRequested as ex:
        msg = 'The follower is shutting down'
        logger.error(msg)
        raise InternalServerError({"code": msg, "description": str(ex)}, status_code=500)
    except NotConnected as ex:
        msg = 'The follower temporarily lost connection to the T2 providers'
        logger.error(msg)
        raise InternalServerError({"code": msg, "description": str(ex)}, status_code=500)
    except Exception as ex:
        msg = 'T2 failure fetching sap document'
        raise InternalServerError({"code": msg, "description": str(ex)}, status_code=500)

    @stream_with_context
    def generate():
        try:
            yield first_chunk
            for _, next_chunk in iterator:
                yield next_chunk
        except T2Timeout as ex:
            msg = 'T2 request timed out'
            logger.error(msg)
            raise InternalServerError({"code": msg, "description": str(ex)}, status_code=500)
        except ShutdownRequested as ex:
            msg = 'The follower is shutting down'
            logger.error(msg)
            raise InternalServerError({"code": msg, "description": str(ex)}, status_code=500)
        except NotConnected as ex:
            msg = 'The follower temporarily lost connection to the T2 providers'
            logger.error(msg)
            raise InternalServerError({"code": msg, "description": str(ex)}, status_code=500)
        except Exception as ex:
            msg = 'T2 failure fetching sap document'
            raise InternalServerError({"code": msg, "description": str(ex)}, status_code=500)

    try:
        response = Response(generate(), mimetype=mime_type)
        response.headers['Content-Disposition'] = 'attachment; filename="{}"'.format(file_name)
        return response
    except Exception:
        logger.exception("get document by type failed")
        raise
