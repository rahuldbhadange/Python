def request_sap_document_type(self, asset_id, document_type):
    """ make a type 2 request for a sap test document
    """
    asset_data = self._basic_data_view.get_asset_data(asset_id)

    # Equnr = asset_data.get("EquipmentNumber")
    print("\n\n")
    pprint(asset_data)
    print("\n\n")
    Equnr = asset_data.get("EngineEquipmentNumber")
    print("\n\n")
    pprint(Equnr)
    print("\n\n")
    rqst_data = {"equnr": Equnr, "document_type": document_type}
    for mime, chunk in self.__follower.t2_request(asset_id, T2_REQUEST_SAP_SDOCK,
                                                  data=json.dumps(rqst_data).encode('utf8'), timeout=100):
        yield mime, chunk