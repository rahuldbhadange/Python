# Provider for SAP Equipment SDOK document
T2_REQUEST_SAP_SDOCK = T2_PROVIDER_SAP_DOCUMENTSINGLE + 'SDOK'
""" Request for SAP SDOK document
UTF8 encoded JSON.
{
    "equnr" : "Equipment number",
    "document_type": "PPM or MOA or IRP"
}
"""
