def __upsert_testdocuments(self, event):
    data_to_insert = {
        "ID": "TestBenchDocument",
        "Type": "SapTestDocumentSet",
        "Revision": "No Data From Source",
        "Title": "Test Bench",
        "Description": "Test Bench document",
        "CreationDate": "",
        "ModifiedDate": "",
        "_file_ext": "pdf",
        "Link": "test-document/{}/MOA".format(event.asset),
        "asset_id": event.asset,
        "source": "sapequipmenthistory"
    }
    self._data_access.upsert(self.DOC_LIST_TABLE,
                             event.asset, data_to_insert, {"asset_id": event.asset, "ID": data_to_insert['ID']})

    data_to_insert = {
        "ID": "StationAcceptanceDocument",
        "Type": "SapTestDocumentSet",
        "Revision": "No Data From Source",
        "Title": "Station Acceptance Test",
        "Description": "Station Acceptance Test document",
        "CreationDate": "",
        "ModifiedDate": "",
        "_file_ext": "pdf",
        "Link": "test-document/{}/PPM".format(event.asset),
        "asset_id": event.asset,
        "source": "sapequipmenthistory"
    }
    self._data_access.upsert(self.DOC_LIST_TABLE,
                             event.asset, data_to_insert, {"asset_id": event.asset, "ID": data_to_insert['ID']})

    data_to_insert = {
        "ID": "Installation Report",
        "Type": "SapTestDocumentSet",
        "Revision": "No Data From Source",
        "Title": "Installation Report",
        "Description": "Installation Report Test document",
        "CreationDate": "",
        "ModifiedDate": "",
        "_file_ext": "pdf",
        "Link": "test-document/{}/IPR".format(event.asset),
        "asset_id": event.asset,
        "source": "sapequipmenthistory"
    }
    self._data_access.upsert(self.DOC_LIST_TABLE,
                             event.asset, data_to_insert, {"asset_id": event.asset, "ID": data_to_insert['ID']})
