# # class Config(object):
# #     # SQLALCHEMY_TRACK_MODIFICATIONS = False
# #     # SECRET_KEY = os.urandom(32)
# #     # # ...
# def Config():
#     USER = 'talendtimdocument'
#     PASS = 'talendtimdocument'
#
# Config()
# # try:
# #    from app.local_settings import Config
# # except ImportError:
# #     pass


USER = 'talendtimdocument'
PASS = 'talendtimdocument'
