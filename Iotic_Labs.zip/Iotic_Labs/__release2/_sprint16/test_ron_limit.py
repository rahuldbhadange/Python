import datetime
from pprint import pprint

import pytz
from rrps.dt.events import (TalendTimDocumentSet, SapMasterDataSet, SapWarrantyRecallSet,
                            SapBomAsBuiltSet, SapBomAsIbaseChangesSet, TalendFirmwareSet)
from rrps.dt.follower.rest_follower.views import BaseView, BasicDataView, RiverOfNewsView


def test_ron_limit(app_client, data_access):

    basic_data = BasicDataView(data_access)
    ron_view = RiverOfNewsView(data_access, basic_data)
    event_time = datetime.datetime.now()

    crtim = "20180212085321"
    uptim = "20180212085436"
    valfr = "20180212085209"
    valto = "20190312085427"

    events = [
        SapBomAsIbaseChangesSet("123", source="src", time=datetime.now(), data=[
            {
                'Crtim': int(datetime.timestamp(pytz.utc.localize(datetime.strptime(crtim, "%Y%m%d%H%M%S")))),
                'InRecno': '',
                'Maktx': 'DIESEL ENGINE',
                'Matnr': '12V4000G23',
                'Sernr': '000000000526104878',
                'Uptim': int(datetime.timestamp(pytz.utc.localize(datetime.strptime(uptim, "%Y%m%d%H%M%S")))),
                'Valfr': int(datetime.timestamp(pytz.utc.localize(datetime.strptime(valfr, "%Y%m%d%H%M%S")))),
                'Valto': int(datetime.timestamp(pytz.utc.localize(datetime.strptime(valto, "%Y%m%d%H%M%S"))))
            },
            {
                'Crtim': int(datetime.timestamp(pytz.utc.localize(datetime.strptime(crtim, "%Y%m%d%H%M%S")))),
                'InRecno': '051MYoXO7kM{}}PXdttEkG',
                'Maktx': 'OIL PUMP',
                'Matnr': 'XS526180.00006',
                'Sernr': '000000000526104875',
                'Uptim': None,
                'Valfr': int(datetime.timestamp(pytz.utc.localize(datetime.strptime(valfr, "%Y%m%d%H%M%S")))),
                'Valto': None
            }
        ]
        ),
        SapMasterDataSet("123", source="test", time=event_time, data=[
            {
                "EqunrAgg": "000000000200000081",
                "MaktxAgg": "AUFNAHMEKOERPER",
                "MatnrAgg": "Mat0",
                "MaktxEng": "Eng0",
                "SernrAgg": "Sys0",
                "Name1": "Cüst0",
                "EqunrEng": "000000000200000082",
                "MatnrEng": "MotMat0",
                "SernrEng": "EngSer0",
                "Kunde": "kunde",
                "Datab": 0,
                "Datbi": 0,
                "Yybau": "030",
                "Eqfnr": "SORT FIELD AB"
            },
            {
                "EqunrAgg": "000000000200000081",
                "MaktxAgg": "AUFNAHMEKOERPER",
                "MatnrAgg": "Mat0",
                "MaktxEng": "Eng0",
                "SernrAgg": "Sys0",
                "Name1": "Cüst0",
                "EqunrEng": "000000000200000082",
                "MatnrEng": "MotMat0",
                "SernrEng": "EngSer0",
                "Kunde": "kunde",
                "Datab": 0,
                "Datbi": 0,
                "Yybau": "030",
                "Eqfnr": "SORT FIELD AB"
            }
        ]
        )
    ]

    for event in events:
        ron_view.on_event(event)




    # ron_view.on_event(event)

    response = app_client.open("/ron/123").json
    pprint(response)

    assert len(response) == 2

    assert response[0]["Source"] == "src"
    assert response[0]["Type"] == "SapBomIBaseChanges"
    assert response[0]["Description"] == "BoM event: Removal"
    assert response[0]["Attachments"] == []

    assert len(response[0]["Details"]) == 1

    assert response[0]["Details"][0]["DateofRemoval"] == "2019-03-12"
    assert response[0]["Details"][0]["Description"] == "DIESEL ENGINE"
    assert response[0]["Details"][0]["IBaseRecord"] == ""
    assert response[0]["Details"][0]["MaterialNumber"] == "12V4000G23"

    assert response[1]["Source"] == "src"
    assert response[1]["Type"] == "SapBomIBaseChanges"
    assert response[1]["Description"] == "BoM event: Installation"
    assert response[1]["Attachments"] == []

    assert len(response[1]["Details"]) == 1

    assert response[1]["Details"][0]["DateofInstallation"] == "2018-02-12"
    assert response[1]["Details"][0]["Description"] == "OIL PUMP"
    assert response[1]["Details"][0]["IBaseRecord"] == "051MYoXO7kM{}}PXdttEkG"
    assert response[1]["Details"][0]["MaterialNumber"] == "XS526180.00006"
