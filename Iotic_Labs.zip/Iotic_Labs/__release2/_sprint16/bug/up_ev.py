# Copyright (c) 2018 Rolls-Royce Power Systems AG. All rights reserved.


"""Saves Kif (correction in field) data from apWarrantyRecallSet event
"""

import logging

from .BaseView import BaseView

logger = logging.getLogger(__name__)


class UpcomingEventsView(BaseView):

    def on_event(self, event):
        logger.info("%s on_event called", self.__class__.__name__)

        payload = event.data

        mapped_list, remove_list = self._map_list(event, payload)

        for item in mapped_list:
            self._data_access.upsert(self.UPCOMING_EVENTS_DATA_TABLE,
                                     event.asset, item, key={"_clmno": item['_clmno'], "asset_id": event.asset})

        # remove items that have been closed
        for remove_item in remove_list:
            self._data_access.remove(
                self.UPCOMING_EVENTS_DATA_TABLE, event.asset, remove_item)

    def _map_list(self, event, items):
        update_list = []
        remove_list = []

        for item in items:
            if self._is_kif_item_closed(item):
                clmno = item.get("Clmno", "")

                if not clmno:
                    raise ValueError("keying off Clmno for kif data but field missing")

                # this item has been closed so remove from upcoming events
                remove_list.append({"asset_id": event.asset, "_clmno": clmno})
                continue

            mapped_item = self._create_kif_data(event, item)
            update_list.append(mapped_item)

        return update_list, remove_list

    def prune_engine_events(self, asset_data):
        """Removes upcoming events for engines previously installed in the specified aggregate.

        :param asset_data: the basic data for an aggregate asset.
        """
        if asset_data is None:
            return

        asset_id = asset_data.get("asset_id")
        if asset_id is None:
            return

        current_engine_serial = asset_data.get("Engine")
        if current_engine_serial is None:
            return

        try:
            self._data_access.remove_query(self.UPCOMING_EVENTS_DATA_TABLE, {
               "asset_id": asset_id,
               "AssetType": "ENG",
               "AssetSerialNumber": {"$exists": True},  # {{"$exists": True}, {"$ne": current_engine_serial}}
               "AssetSerialNumber": {"$ne": current_engine_serial}
            })
        except:  # pylint: disable=broad-except
            logger.exception("An error occurred pruning engine events for asset %s", asset_id)
