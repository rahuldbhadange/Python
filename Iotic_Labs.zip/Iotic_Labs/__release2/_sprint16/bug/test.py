# self._data_access.remove_query(self.UPCOMING_EVENTS_DATA_TABLE, {
#     "asset_id": asset_id,
#     "AssetType": "ENG",
#     "AssetSerialNumber": {{"$exists": True}, {"$ne": current_engine_serial}}
# # "AssetSerialNumber": {"$ne": current_engine_serial}
