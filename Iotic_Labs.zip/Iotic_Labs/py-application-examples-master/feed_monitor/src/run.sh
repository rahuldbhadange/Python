#!/bin/bash
PYTHONPATH=../3rd python3 -m ExtMon2 ../cfg/extmon2.ini
# After ./make_pyz.sh
# PYTHONPATH=ExtMon2.pyz python3 -m ExtMon2 ../cfg/extmon2.ini
