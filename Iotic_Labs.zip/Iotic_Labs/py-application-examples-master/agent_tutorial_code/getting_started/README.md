
# Agent Tutorial Code - Getting Started

## Purpose
- Provide worked examples that follow the getting started tutorial [here](https://developer.iotic-labs.com/getting-started/getting-started-01-introduction/)

