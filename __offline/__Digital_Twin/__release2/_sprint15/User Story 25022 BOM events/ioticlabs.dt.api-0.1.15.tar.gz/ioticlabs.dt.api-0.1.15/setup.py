# Copyright (c) 2019 Iotic Labs Ltd. All rights reserved.

from os import path
from setuptools import setup, find_packages

PKGDIR = path.abspath(path.dirname(__file__))
with open(path.join(PKGDIR, 'README.md'), encoding='utf-8') as f:
    LONG_DESCRIPTION = f.read()

setup(
    name='ioticlabs.dt.api',
    description='APIs to interact with Iotic digital twins',
    long_description=LONG_DESCRIPTION,
    long_description_content_type='text/markdown',
    version='0.1.15',
    author='Iotic Labs Ltd',
    author_email='info@iotic-labs.com',
    url='https://iotic-labs.com',
    packages=find_packages(),
    zip_safe=True,
    python_requires='>=3.6',
    install_requires=[
        'py-lz4framed==0.13.0',
        'py-IoticAgent>=0.6.9,<0.7.0',
        'fastavro>=0.21.9,<0.22',
        'ioticlabs.dt.common>=0.1.18,<0.2'
    ],
    entry_points={
        'console_scripts': [
            'ioticlabs-dt-event-cli = ioticlabs.dt.api.event.__main__:main'
        ]
    }
)
