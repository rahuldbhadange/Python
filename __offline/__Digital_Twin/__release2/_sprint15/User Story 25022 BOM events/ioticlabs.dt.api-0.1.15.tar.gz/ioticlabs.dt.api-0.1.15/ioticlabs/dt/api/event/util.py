# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

from types import ModuleType
from importlib import import_module

from .base import AssetEvent
from .internal import _InternalEvent


def module_event_class_iterator(module, recurse=True, internal=False, on_import_error=None):
    """Generator of AssetEvent classes found in the given module. Ignores any attributes which begin with an underscore
    as well as any internal events.

    module - absolute/full module name from which to import or an actual module
    recurse - whether to consider any modules within the module also (i.e. which have been imported)
    internal - filters for _InternalEvent if set, otherwise filters for anything but said class
    import_error - function to call (optional) if importing fails. This is called within an except block and the
        exception is passed as the only argument.
    """
    if not isinstance(module, ModuleType):
        try:
            module = import_module(module)
        except Exception as ex:  # pylint: disable=broad-except
            if on_import_error:
                on_import_error(ex)
            return

    yield from _event_class_iterator(module, recurse, internal, set())


def _event_class_iterator(module, recurse, internal, seen):
    """Used by module_event_class_iterator"""
    # Avoid circular recursion by skipping previously seen modules
    seen.add(module)

    for name in filter(lambda x: not x.startswith('_'), sorted(dir(module))):
        item = getattr(module, name)
        try:
            if issubclass(item, AssetEvent):
                if item == AssetEvent or (internal ^ issubclass(item, _InternalEvent)):
                    continue
                yield item
        except TypeError:
            pass
        if recurse and isinstance(item, ModuleType) and item not in seen:
            yield from _event_class_iterator(item, True, internal, seen)
