# Copyright (c) 2019 Iotic Labs Ltd. All rights reserved.

import logging
from time import monotonic
from threading import Thread, Event
from contextlib import contextmanager
from concurrent.futures import as_completed
from collections import namedtuple, deque
from collections.abc import Mapping
from itertools import chain
from functools import partial
from abc import ABCMeta, abstractmethod
from warnings import warn

from IoticAgent.IOT import Client, DescribeScope
from IoticAgent.IOT.Exceptions import IOTUnknown, IOTAccessDenied, IOTSyncTimeout, LinkException, LinkShutdownException
from IoticAgent.Core.Const import M_RESOURCE, R_SUB

from ioticlabs.dt.common.discovery import DiscoveryConfig, get_asset_points_for_thing
from ioticlabs.dt.common.defaults import T2Provider
from ioticlabs.dt.common.meta import ThingMeta, search_iter
from ioticlabs.dt.common.util import NestedConfig, in_own_thread_single, non_empty_str, positive_int
from ioticlabs.dt.common.scheduler import ScheduledPool
from ioticlabs.dt.common.values.es import get_es_template_for_control
from ioticlabs.dt.common.values.t2 import T2_VALUES_REQ_DT, T2ProviderFailureReason  # noqa: F401
from ioticlabs.dt.common.util.agent import get_agent_status, AgentStatus  # noqa: F401

from ..event.base import AssetEvent
from ..event.internal import SOURCE_IOTIC_INTERNAL
from ..event.registry import (  # noqa: F401
    load_event_registry, UnknownEvent, UnknownVersion, EncodeDecodeError, ValidationError
)
from .exceptions import (  # noqa: F401
    AssetUnknown, IntegratorException, ShutdownRequested, EventPublishFailure, T2ResponseFailure
)
from ..t2.chunked import LargeResponse
from ..t2.wrappers import T2Request, T2Response

log = logging.getLogger(__name__)
DEBUG_ENABLED = log.isEnabledFor(logging.DEBUG)


class IntegratorCallbacks(metaclass=ABCMeta):
    """Set of callbacks which integrator implementations must provide.

    Note:
        Methods herein should not perform long-running tasks and instead delegate to make necessary changes.
    """

    @abstractmethod
    def on_asset_created(self, asset_id):
        """A new asset has been created. Called once for each known asset on startup as well as whenever a new asset
        appears whilst the integrator is running.
        """
        raise NotImplementedError

    @abstractmethod
    def on_asset_deleted(self, asset_id):
        """An asset has been deleted. Called whenever an asset has been removed and should no longer be considered by
        the integrator.

        Note:
            This is NOT called if an asset has been deleted whilst the integrator is not running.
        """
        raise NotImplementedError

    @abstractmethod
    def on_t2_request(self, request):
        """A new type2 request has been made for a particular asset.

        Args:
            request: Instance of T2Request
        """
        raise NotImplementedError


# Brief status of integrator
IntegratorStatus = namedtuple('IntegratorStatus', 'running agent t2_enabled asset_count')
"""
Integrator status summary

running - integrator has been started
agent - instance of AgentStatus
t2_enabled - whether T2 functionality is enabled in this integrator
asset_count - number of assets this integrator is currently aware of
"""

# Id of asset, RemoteControl instance
_KnownAsset = namedtuple('_KnownAsset', 'id_ publish_control t2rsp_control')

# raw within is original config Mapping
_IntegratorConfig = namedtuple('_IntegratorConfig', 'raw source publish_timeout')


class _T2Config(namedtuple('_T2Config', 'enabled max_chunk_size')):

    @classmethod
    def from_config(cls, config):
        enabled = NestedConfig.get(config, 'asset.type2.enabled', required=False, default=False, check=bool)
        enabled_old = NestedConfig.get(config, 'asset.with_type2', required=False, default=None, check=bool)
        if enabled_old is not None:
            warn('Use asset.type2.enabled instead of asset.with_type2', DeprecationWarning)
            enabled = enabled_old

        return cls(
            # Whether type2 request functionality should be enabled
            enabled=enabled,
            max_chunk_size=NestedConfig.get(
                # default ~95% of 64kB standard QAPI request size limit
                config, 'asset.type2.max_chunk_size', required=False, default=62208,
                # only really meant to be increased, so set a fairly high minimum
                check=lambda x: positive_int(x) and x >= (1024 * 16)
            )
        )


class Integrator:
    """Provides asset notifications as well as event publishing functionality."""

    def __init__(self, config, client, callbacks):
        """Instantiate integrator. Use start() to actually begin asset discovery.

        Args:
            config: Nested configuration mapping for integrator
            client: Agent to use for Iotic Space communication (instance of IoticAgent.IOT.Client). This client must be
                running by the time this class' start() method is called.
            callbacks: Instance of class implementing IntegratorCallbacks
        """
        if not isinstance(config, Mapping):
            raise TypeError('config')
        if not isinstance(client, Client):
            raise TypeError('client')
        if not isinstance(callbacks, IntegratorCallbacks):
            raise TypeError('callbacks')
        client.register_callback_deleted(self.__cb_iotic_deleted, serialised=False)
        self.__client = client
        self.__callbacks = callbacks
        # Thing through which events are published
        self.__thing = None
        # Holds all event types available for publishing
        self.__registry = load_event_registry(NestedConfig.get(
            config, 'asset.event.modules', required=False, default=(),
            check=lambda x: NestedConfig.Check.seq_non_empty_str(x, zero_items_allowed=True)
        ))
        # Mapping of asset id to _KnownAsset instance. WARNING: Currently only updated in background thread so no
        # locking required as long as all iterable access is materialised in advance.
        self.__assets = {}
        # Pending deletions (via agent notifications) which should be applied to assets.
        self.__deleted = deque()
        self.__t2_config = _T2Config.from_config(config)
        self.__asset_watcher_thread = Thread(
            target=self.__asset_watcher_run,
            args=(DiscoveryConfig.from_config(config, producer=True, with_t2=self.__t2_config.enabled),),
            name='watcher', daemon=True
        )
        self.__end = Event()
        self.__end.set()
        self.__cfg = _IntegratorConfig(
            raw=config,
            source=NestedConfig.get(
                config, 'source', check=lambda x: NestedConfig.Check.non_empty_str(x) and x != SOURCE_IOTIC_INTERNAL
            ),
            publish_timeout=NestedConfig.get(
                config, 'asset.event.publish.timeout', required=False, default=30,
                check=lambda x: NestedConfig.Check.positive_int(x) and x >= 10
            )
        )
        self.__pool = ScheduledPool(
            max_workers=NestedConfig.get(
                config, 'workers', required=False, default=2, check=lambda x: isinstance(x, int) and x > 0
            ),
            thread_name_prefix='iworker'
        )

    def start(self):
        """Starts the integrator. Other public methods herein must not be called beforehand. Should be called after
        starting Iotic agent. Alternatively use with keyword on the instance."""
        log.debug('Starting source %s', self.__cfg.source)
        self.__end.clear()
        self.__create_thing()
        self.__pool.start()
        self.__asset_watcher_thread.start()

    def stop(self, timeout=10):
        """Stops the integrator. Should be called before shutting down the Iotic agent."""
        self.__end.set()
        self.__asset_watcher_thread.join(timeout=timeout)
        if self.__asset_watcher_thread.is_alive():
            log.warning('Asset watcher thread still running')
        self.__pool.stop()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop()

    @property
    def status(self):
        """Status summary as IntegratorStatus instance"""
        return IntegratorStatus(
            running=(not self.__end.is_set()),
            agent=get_agent_status(self.__client),
            t2_enabled=self.__t2_config.enabled,
            asset_count=len(self.__assets)
        )

    @property
    def assets(self):
        """Sequence of assets (snapshot) known to integrator internally. on_asset_* callbacks should be used to
        determine what assets exist rather than polling this."""
        return tuple(self.__assets)

    @property
    def _own_thing(self):
        """Iotic Thing which follower uses to receive events with.

        Warning:
            This is exposed for extending functionality only and care must be taken when modifying it so as to not clash
            with existing settings, points and metadata."""
        return self.__thing

    def publish_event(self, event, confirm=True, retry=False):
        """Publish an event for a given asset.

        Args:
            event: Instance of AssetEvent implementing class. If time is not specified, current UTC time will be used.
                The source field is also ignored (and set based on configuration).
            confirm:Confirm delivery of the event. If set, this method will block until the event has been published.
                Otherwise it will return immediately and publish failures will be ignored.
            retry: Automatically retry event publishing until it succeeds or shutdown has been requested.

        Raises:
            TypeError: If the event is invalid
            AssetUnknown: If the integrator is currently not handling this asset.
            ShutdownRequested: If shutdown is requested whilst publishing the event.
            EventPublishFailure: If the event could not be published. Timeouts are governed by agent and integrator
                configuration and are **only** raised if retry=False.
            UnknownEvent: Event is not registered.
            UnknownVersion: Event version not known for registered event.
            EncodeDecodeError: Extra data cannot be encoded.
            ValidationError: Additional type data validation failed.
        """
        if not isinstance(event, AssetEvent):
            raise TypeError('event')
        try:
            asset = self.__assets[event.asset]
        except KeyError as ex:
            raise AssetUnknown(event.asset) from ex

        template = get_es_template_for_control()
        self.__registry.encode_into(event, template)
        # Fixed, i.e. ignored if set in event instance
        template.values.source = self.__cfg.source
        last_log_time = monotonic()

        while True:
            try:
                self.__publish_event(asset, template, confirm)
            except EventPublishFailure as ex:
                if not retry:
                    raise
                # At most output error as often as configured timeout
                if monotonic() - last_log_time >= self.__cfg.publish_timeout:
                    log.error(
                        'Failed to publish %s for %s, will retry (reason: %s)', event.name(), event.asset,
                        ex.reason
                    )
                    last_log_time = monotonic()
                # Delay before retrying since agent might currently be offline. Exit if shutdown has been requested in
                # the mean time.
                if self.__end.wait(2):
                    raise ShutdownRequested from ex
                continue
            break

    def __publish_event(self, asset, template, confirm):
        try:
            if confirm:
                result = asset.publish_control.tell(template, timeout=self.__cfg.publish_timeout)
            else:
                asset.publish_control.ask(template)
                result = True
        except IOTUnknown as ex:
            raise AssetUnknown(asset.id_) from ex
        # subclasses LinkException
        except LinkShutdownException as ex:
            raise ShutdownRequested from ex
        except LinkException as ex:
            raise EventPublishFailure(asset.id_, EventPublishFailure.Reason.NOT_CONNECTED) from ex
        except IOTSyncTimeout as ex:
            raise EventPublishFailure(asset.id_, EventPublishFailure.Reason.LOCAL_TIMEOUT) from ex

        if result is not True:
            raise EventPublishFailure.from_tell_result(asset.id_, result)

    def t2_respond_error(self, request, reason, wait=True):
        """Send failure response for the given type2 request. No longer existing assets are silently ignored.

        Args:
            request: T2Request instance
            reason: T2ProviderFailureReason instance
            wait: Whether to block until underlying agent request completes. Otherwise returns as soon as the request
                has been enqueued.

        Raises:
            TypeError: If the request or reason is invalid
            ShutdownRequested: If shutdown is requested whilst sending response
            T2ResponseFailure: If the response could not be sent. Timeouts are goverend by agent and integrator
                configuration.
        """
        try:
            rsp_control = self.__assets[request.asset_id].t2rsp_control
        except KeyError:
            return

        # request & reason will be validated via T2Response.from_request_with_error call
        mime, raw_payload = T2Response.from_request_with_error(request, reason).to_provider_response()
        try:
            (rsp_control.ask if wait else rsp_control.ask_async)(raw_payload, mime=mime)
        except IOTUnknown:
            pass
        # subclasses LinkException
        except LinkShutdownException as ex:
            raise ShutdownRequested from ex
        # The following only apply for wait=True
        except LinkException as ex:
            raise T2ResponseFailure(request.asset_id, T2ResponseFailure.Reason.NOT_CONNECTED) from ex
        except IOTSyncTimeout as ex:
            raise T2ResponseFailure(request.asset_id, T2ResponseFailure.Reason.LOCAL_TIMEOUT) from ex

    def t2_respond(self, request, mime, data, wait=True):
        """Send response for the given type2 request. If a large amount of data is to be returned, t2_respond_streamed
        is preferred.

        Args:
            request: T2Request instance
            mime: Mime type of data (string, required)
            data: Bytes (i.e. raw response)
            wait: Whether to block until all underlying agent requests complete. Otherwise returns as soon as all
                requests have been enqueued.

        Raises:
            TypeError: If the request is invalid
            ValueError: If mime or data are invalid
            AssetUnknown: If the asset is no longer known. In this case the original t2 request should be ignored
            ShutdownRequested: If shutdown is requested whilst sending response
            T2ResponseFailure: If the response could not be sent. Timeouts are goverend by agent and integrator
                configuration.
        """
        # Could use LargeResponse.send() instead but then would need additional validation here
        with self.t2_respond_streamed(request, mime, wait=wait) as write:
            write(data)

    @contextmanager
    def t2_respond_streamed(self, request, mime, wait=False):
        """Streaming version of t2_respond. Provides context-managed function which accepts one argument: data (bytes).
        See t2_respond for more details and applicable exceptions. Expected usage::

            with t2_respond_streamed(req, 'application/some-mime') as write:
                for chunk in response_data:
                    write(chunk)
        """
        if not isinstance(request, T2Request):
            raise TypeError('request')
        if not non_empty_str(mime):
            raise ValueError('mime')

        try:
            rsp_control = self.__assets[request.asset_id].t2rsp_control
        except KeyError as ex:
            raise AssetUnknown(request.asset_id) from ex

        try:
            with LargeResponse(rsp_control, request, mime, self.__t2_config.max_chunk_size).writer(wait=wait) as write:
                yield write
        # subclasses LinkException
        except LinkShutdownException as ex:
            raise ShutdownRequested from ex
        # The following only apply for wait=True
        except LinkException as ex:
            raise T2ResponseFailure(request.asset_id, T2ResponseFailure.Reason.NOT_CONNECTED) from ex
        except IOTSyncTimeout as ex:
            raise T2ResponseFailure(request.asset_id, T2ResponseFailure.Reason.LOCAL_TIMEOUT) from ex

    def __create_thing(self):
        client = self.__client
        cfg = self.__cfg

        self.__thing = thing = client.create_thing(
            NestedConfig.get(cfg.raw, 'thing.lid', check=NestedConfig.Check.non_empty_str)
        )
        if thing.agent_id != client.agent_id:
            log.warning('Reassigning %s from %s', thing.lid, thing.agent_id)
            thing.reassign(client.agent_id)

        thing_meta = ThingMeta.from_config(cfg.raw, 'thing', tag_default=())

        if thing_meta.tags:
            thing.create_tag(thing_meta.tags)
        elif self.__t2_config.enabled:
            # Tags are need to identify
            log.warning('Using default tags for t2 provider')
            thing.create_tag(T2Provider.Thing.TAGS + (T2Provider.Thing.TAG_PREFIX + cfg.source,))
        if thing_meta.label or thing_meta.description:
            with thing.get_meta() as meta:
                if thing_meta.label:
                    meta.set_label(thing_meta.label)
                if thing_meta.description:
                    meta.set_description(thing_meta.description)

        if self.__t2_config.enabled:
            self.__setup_type2_provider(thing)

    def __setup_type2_provider(self, thing):
        """Configured control to receive type2 requests"""
        log.info('Type2 provider will be enabled')
        control = thing.create_control(
            NestedConfig.get(
                self.__cfg.raw, 'point.lid.t2req', required=False, default=T2Provider.Point.T2.REQ_LID,
                check=NestedConfig.Check.non_empty_str
            ),
            self.__cb_t2_req
        )
        with control.get_meta() as meta:
            meta.set_label(NestedConfig.get(
                self.__cfg.raw, 'point.label.t2req', required=False, default=T2Provider.Point.T2.REQ_LABEL,
                check=NestedConfig.Check.non_empty_str
            ))

        for value in T2_VALUES_REQ_DT:
            control.create_value(value.label, vtype=value.type_, unit=value.unit, description=value.description)

    def __asset_watcher_run(self, discovery_config):
        """Responsible for periodically updating known asset list and subscription management"""
        log.info('Started')
        try:
            self.__watcher_loop(discovery_config)
        except:
            log.critical('Watcher loop failure', exc_info=True)
        log.info('Finished')

    def __cb_iotic_deleted(self, args):
        if args[M_RESOURCE] == R_SUB:
            subs = set(args['ids'])
            for asset in tuple(self.__assets.values()):
                if asset.publish_control.subid in subs:
                    log.debug('Asset %s to be removed', asset.id_)
                    self.__deleted.append(asset.id_)
                    subs.remove(asset.publish_control.subid)
                    if not subs:
                        break

    def __watcher_loop(self, discovery_config):
        end = self.__end

        while not end.is_set():
            start = monotonic()
            log.debug('Performing asset search')

            try:
                found = self.__found_assets(discovery_config)
                # Removing first since might attempt re-adding (for notified unsubscriptions)
                self.__update_assets_remove(found)
                self.__update_assets_add(found)
            except LinkShutdownException:
                # Shutdown requested whilst request pending
                return
            except:
                # not important on shutdown (client might already be stopped)
                if not end.is_set():
                    log.error('Discovery/update failure', exc_info=log.isEnabledFor(logging.DEBUG))

            log.debug('Asset update complete')
            end.wait(max(0, discovery_config.interval - (monotonic() - start)))

    def __update_assets_remove(self, found):
        """Remove any assets which are not in found list as well as actioning any space-notified deletions."""
        update_assets_remove_one = self.__update_assets_remove_one
        submit_with_future = self.__pool.submit_with_future

        # Wait for all additions to finish as do not want to overlap long running addition with next discovery loop
        for future in as_completed(
                submit_with_future(update_assets_remove_one, id_)
                # Remove unknown ones (and any which have been notified as deleted)
                for id_ in chain(
                    # (False positive) pylint: disable=bad-continuation
                    tuple(self.__assets.keys()) - found.keys(),
                    # Since not dequeued anywhere else, safe to pop by length. Use set as could contain duplicates since
                    # notifications can be about both replay control and event feed
                    {self.__deleted.popleft() for _ in range(len(self.__deleted))}
                )
        ):
            ex = future.exception()
            if ex:
                log.error('Unexpected failure whilst removing asset', exc_info=(ex if DEBUG_ENABLED else None))

    @staticmethod
    def __remove_control(asset_id, thing, control):
        """Tries to unattach from control. Returns True on success, False on failure and None if shutdown requested"""
        try:
            thing.unattach(control)
        except IOTUnknown:
            # Might have been deleted remotely in mean time
            pass
        except LinkShutdownException:
            # Shutdown requested whilst request pending
            return None
        except:
            log.error(
                'Failed to remove asset %s control %s, will attempt again on next update', asset_id, control,
                exc_info=log.isEnabledFor(logging.DEBUG)
            )
            return False

        return True

    def __update_assets_add(self, found):
        """Add any assets which have been newly found"""
        update_asset_add_one = self.__update_asset_add_one
        submit_with_future = self.__pool.submit_with_future

        # Wait for all additions to finish as do not want to overlap long running addition with next discovery loop
        for future in as_completed(
                # found[id_] => publish_control, t2rsp_control
                submit_with_future(update_asset_add_one, id_, *found[id_])
                for id_ in tuple(found.keys() - self.__assets.keys())
        ):
            ex = future.exception()
            if ex:
                log.error('Unexpected failure whilst adding asset', exc_info=(ex if DEBUG_ENABLED else None))

    @staticmethod
    def __attach_to(asset_id, thing, control_guid):
        """Tries to attach to control. Returns remote control on success, False on failure and None if shutdown
        requested.
        """
        try:
            return thing.attach(control_guid)
        except IOTUnknown:
            # Might have been deleted in mean time return False
            pass
        except LinkShutdownException:
            # Shutdown requested whilst request pending
            return None
        except IOTAccessDenied:
            # TODO - ignore assets after this?
            log.warning('Asset %s subscription (to %s) denied', asset_id, control_guid)
        except:
            log.error(
                'Failed to attach to asset %s (%s), will attempt again on next update', asset_id, control_guid,
                exc_info=log.isEnabledFor(logging.DEBUG)
            )
        return False

    def __update_assets_remove_one(self, id_):
        """Blindly removes the given asset, if it is known locally. For use with async pool. Should NOT be called
        multiple times in parallel for the same asset id_.
        """
        log.info('Removing asset %s', id_)
        # Since dealing with more than one subscription, remove local asset reference at this stage so can ignore
        # second sub deletion (in __cb_iotic_deleted callback). Otherwise could have endless loop of a) asset sub
        # deleted, b) asset removed (generates another sub deleted callback), c) asset re-subscribed, d) asset
        # deleted again due to (b).
        try:
            asset = self.__assets.pop(id_)
        except KeyError:
            # Delete-notified asset already removed previously
            return

        result = False
        for control in (asset.publish_control, asset.t2rsp_control):
            # Might not apply (e.g. type2 not enabled)
            if not control:
                continue
            result = self.__remove_control(id_, self.__thing, control)
            if result is None:
                # shutdown requested (see __attach_to)
                return
            if not result:
                # failed to remove
                break

        if result:
            self.__do_callback('on_asset_deleted', id_)
        else:
            # Retain reference so can attempt removal later
            self.__assets[id_] = asset

    def __update_asset_add_one(self, id_, publish_control, t2rsp_control):
        """Blindly adds the given asset, i.e. asset is expected to be unknow. For use with async pool. Should NOT be
        called multiple times in parallel for the same asset id_.
        """
        thing = self.__thing

        publish_control = self.__attach_to(id_, thing, publish_control)
        if not publish_control:
            # failed to attach or shutdown requested (see __attach_to)
            return
        # T2 might not be enabled
        if t2rsp_control:
            t2rsp_control = self.__attach_to(id_, thing, t2rsp_control)
            if t2rsp_control is None:
                # shutdown requested
                return
            if not t2rsp_control:
                self.__remove_control(id_, thing, publish_control)
                return

        self.__assets[id_] = _KnownAsset(id_, publish_control, t2rsp_control)
        log.info('Added asset %s', id_)
        self.__do_callback('on_asset_created', id_)

    @in_own_thread_single
    def __do_callback(self, name, *args, **kwargs):
        try:
            getattr(self.__callbacks, name)(*args, **kwargs)
        except:
            log.warning('%s(*%s, **%s) failed', name, args, kwargs, exc_info=log.isEnabledFor(logging.DEBUG))

    def __found_assets(self, discovery_config):
        """Performs search and returns mapping of asset id to tuple of control (replay) & feed (event) guids for
        matching ones.
        """
        submit_with_future = self.__pool.submit_with_future
        get_produce_points = partial(
            get_asset_points_for_thing, self.__client, DescribeScope(discovery_config.scope.value),
            discovery_config.meta, require_feed=False, require_t2=self.__t2_config.enabled
        )

        return {
            asset_id: (publish_guid, t2_rsp_guid)
            for asset_id, publish_guid, t2_rsp_guid, _ in filter(
                # get_produce_points will return None result when not a valid asset - using filter() to ignore
                None,
                # Note: Future.result() will raise Exception on failure which is handled higher up
                map(lambda x: x.result(), as_completed(
                    # Determine whether valid assets and get relevant details
                    submit_with_future(get_produce_points, guid)
                    # Retrieve potential asset things
                    for guid in search_iter(
                        # Current 'reduced' search type is limited to 200 results
                        self.__client, text=discovery_config.text, scope=discovery_config.scope, reduced=True, limit=200
                    )
                ))
            )
        }

    def __cb_t2_req(self, control_args):
        try:
            req = T2Request.from_control_args(control_args)
        except:
            log.warning('Unparsable t2 req (sub %s), ignoring', control_args['subId'], exc_info=DEBUG_ENABLED)
            return

        if req.asset_id not in self.__assets:
            log.debug('Ignoring t2 req for unknown assets %s', req.asset_id)
            return

        self.__do_callback('on_t2_request', req)
