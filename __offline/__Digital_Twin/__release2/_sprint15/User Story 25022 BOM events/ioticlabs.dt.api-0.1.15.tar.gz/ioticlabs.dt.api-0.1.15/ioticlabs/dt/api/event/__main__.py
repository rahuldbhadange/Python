# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

from argparse import ArgumentParser
from traceback import print_exception
from sys import exc_info

from .util import module_event_class_iterator
from .registry import AssetEventRegistry


class Utility:

    def __init__(self):
        self.__parse_args()

    def __parse_args(self):
        """Command line arguments specific to checker"""
        parser = ArgumentParser(description='Iotic DT events utility')
        subparsers = parser.add_subparsers(dest='cmd', title='Command')
        subparsers.required = True

        checker = subparsers.add_parser('check', help='Check/validate defined event types')
        checker.add_argument('modules', nargs='+', metavar='MODULE', help='Module to load event types from')
        checker.add_argument('-s', '--stop', action='store_true', help='Whether to stop after first error')
        checker.add_argument('-v', '--verbose', action='store_true', help='Whether to print detailed error output')
        checker.add_argument('-i', '--internal', action='store_true', help='Whether to look for internal events')
        checker.set_defaults(func=self.__checker)

        self.__args = parser.parse_args()

    def __error(self, msg=None, do_exit=False):
        info = exc_info()
        if not msg and info[0]:
            msg = info[1]
        print(('ERROR: %s' % msg) if msg else 'ERROR')
        if self.__args.verbose:
            if info[0]:
                print_exception(*info)
        if self.__args.stop or do_exit:
            exit(1)

    def __checker(self):
        error = self.__error
        args = self.__args

        classes = 0
        valid = 0
        registry = AssetEventRegistry()

        def on_import_error(_):
            self.__error('Failed to import module "%s"' % module)  # pylint: disable=undefined-loop-variable

        for module in args.modules:
            module_classes = 0
            print('+ %s' % module)

            for item in module_event_class_iterator(module, internal=args.internal, on_import_error=on_import_error):
                print('  - %s ... ' % item.__name__, end='')
                classes += 1
                module_classes += 1

                try:
                    added = registry.register(item)
                except:
                    error()
                    continue
                if added:
                    valid += 1
                    print('OK')
                else:
                    classes -= 1
                    module_classes -= 1
                    print('DUPLICATE')

            if not module_classes:
                error('No %sevent types found in module: %s' % ('(new) ' if classes else '', module))

        if classes:
            msg = '%d/%d event types valid' % (valid, classes)
            print('%s\n%s' % ('-' * len(msg), msg))
        else:
            error('No event types found in any modules')

    def run(self):
        self.__args.func()


def main():
    Utility().run()


if __name__ == '__main__':
    main()
