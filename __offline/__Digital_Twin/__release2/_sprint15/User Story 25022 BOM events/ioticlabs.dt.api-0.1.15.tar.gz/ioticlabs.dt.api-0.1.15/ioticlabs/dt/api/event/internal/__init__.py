# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

"""Event types internal to ES provider. These are not expeced to be encoded/decoded. The version data definitions exist
only to highlight what data these events will contain."""

from enum import Enum, unique

from ..base import AssetEvent, field
from ..exceptions import UnknownEvent, UnknownVersion, EncodeDecodeError, ValidationError


# Source reserved for internal event
SOURCE_IOTIC_INTERNAL = '_IOTIC_INTERNAL'


class _InternalEvent(AssetEvent):  # pylint: disable=abstract-method
    """Base class for all internal events"""


class _PlainInternalEvent(_InternalEvent):
    """Template for internal events without data"""

    @classmethod
    def _default_version(cls):
        return 1

    @classmethod
    def _known_versions(cls):
        return {1: None}


class _DataInternalEvent(_InternalEvent):  # pylint: disable=abstract-method
    """Template for internal events with extra data"""

    @classmethod
    def _default_version(cls):
        return 1


class IntTwinEofReplay(_PlainInternalEvent):
    """Replay finished. Offset is set to latest event sent before EOF."""
    pass


class IntTwinEofShutdown(_PlainInternalEvent):
    """Replay (or feed) stopping due to shutdown. Offset is set to latest event sent before EOF."""
    pass


class IntTwinEventInvalid(_PlainInternalEvent):
    """Invalid event in stream, i.e. decoding failure when reading from actual event log/storage."""
    pass


class IntFollowerStartReplay(_PlainInternalEvent):
    """Replay started (twin has acknowledged it). Offset is starting offset for replay request."""

    @classmethod
    def for_asset(cls, asset_id, offset):
        return cls(asset_id, source=SOURCE_IOTIC_INTERNAL, offset=offset)


class IntFollowerEventInvalid(_DataInternalEvent):
    """Event parsing/decode failure at follower end"""

    @unique
    class Reason(str, Enum):
        UNKNOWN_EVENT = 'UNKNOWN_EVENT'
        UNKNOWN_VERSION = 'UNKNOWN_VERSION'
        # Extra data decoding
        DECODE_ERROR = 'DECODE_ERROR'
        # Extra data validation
        VALIDATION_ERROR = 'VALIDATION_ERROR'

    @classmethod
    def _known_versions(cls):
        return {
            1: {
                'type': 'record',
                'name': 'ErrorDetail',
                'doc': 'Details about event for which decoding failed',
                'fields': [
                    field('type', 'string', doc='Event type'),
                    field('version', ['null', 'int'], doc='Event type version'),
                    field(
                        'reason',
                        {
                            'type': 'enum',
                            'name': 'Reason',
                            'symbols': tuple(cls.Reason)
                        },
                        doc='Why decoding failed'
                    )
                ]
            }
        }

    # This is not great given we're defining exception, reason (Enum) and mapping. It is however only for an internal
    # method at this point.
    __exc_to_reason = {
        UnknownEvent: Reason.UNKNOWN_EVENT,
        UnknownVersion: Reason.UNKNOWN_VERSION,
        EncodeDecodeError: Reason.DECODE_ERROR,
        ValidationError: Reason.VALIDATION_ERROR
    }

    @classmethod
    def _from_registry_exception(cls, exc, asset_id, template, systime):
        """Produces instance of this class for the given registry-related exception."""
        # Note: Expecting seq/offset & systime to be available as Feed/Control value parsing failure should not lead to
        # this Event being created. (That is classified as a lower level internal failure.)
        return cls(
            asset_id,
            source=SOURCE_IOTIC_INTERNAL,
            offset=template.values.seq,
            systime=systime,
            data={
                'type': exc.event_type,
                # Not available for all exceptions
                'version': getattr(exc, 'version', None),
                'reason': cls.__exc_to_reason.get(type(exc))
            }
        )


@unique
class IoticInternalTwinEvent(str, Enum):
    """Names of events emitted by ES twin/provider itself"""
    EOF_REPLAY = IntTwinEofReplay.name()
    EOF_SHUTDOWN = IntTwinEofShutdown.name()
    EVENT_INVALID = IntTwinEventInvalid.name()
