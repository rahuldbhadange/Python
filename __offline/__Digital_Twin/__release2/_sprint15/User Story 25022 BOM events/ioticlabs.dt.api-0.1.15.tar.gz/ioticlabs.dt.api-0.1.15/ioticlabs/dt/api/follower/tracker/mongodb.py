# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

import logging
from time import monotonic
from threading import Thread, Event, RLock
from collections.abc import Mapping

from ioticlabs.dt.common.util import NestedConfig
from ioticlabs.dt.common.item_cache.mongodb import Mongodb as MongodbItemCache

from . import TrackerBase

log = logging.getLogger(__name__)
DEBUG_ENABLED = log.isEnabledFor(logging.DEBUG)


class Mongodb(TrackerBase):
    """Tracker based on Mongodb item cache (from dt.common package). Assumes this is the only process tracking assets
    with the given DB configuration.
    """

    __item_field = 'a'
    __offset_field = 'o'

    def __init__(self, config):
        super().__init__(config)
        self.__interval = NestedConfig.get(
            config, 'write_interval', required=False, default=10,
            check=lambda x: isinstance(x, (int, float)) and x >= 0.5
        )
        cache_conf = NestedConfig.get(config, 'conn', required=True, check=lambda x: isinstance(x, Mapping))

        if 'item_field' in cache_conf:
            log.warning('Ignoring conn.item_field configuration parameter (since is fixed to "%s")', self.__item_field)
        cache_conf['item_field'] = self.__item_field

        self.__cache = MongodbItemCache(cache_conf)
        # Mapping of asset id to offset. Cached version of latest offsets
        self.__assets = {}
        # Most recent pending updates applicable, per asset. Either numeric offset or None if asset is to be removed.
        self.__updates = {}
        # For serialising access to __assets & __updates mappings
        self.__lock = RLock()
        # Background persistence thread
        self.__thread = None
        # Shutdown control
        self.__end = Event()

    def start(self):
        if self.__thread:
            raise ValueError('Already running')
        self.__cache.start()
        self.__thread = Thread(target=self.__bg_thread, name='mongodb_tracker', daemon=True)
        self.__thread.start()

    def stop(self, timeout=10):
        self.__end.set()
        start = monotonic()
        if self.__thread:
            self.__thread.join(timeout)
            if self.__thread.is_alive():
                log.warning('BG thread still running')
            else:
                self.__thread = None
        self.__cache.stop(timeout=max(0, timeout - (monotonic() - start)))

    def __bg_thread(self):
        log.debug('Started')
        end_wait = self.__end.wait
        interval = self.__interval
        persist = self.__persist
        lock = self.__lock

        start = monotonic()
        while not end_wait(max(0, interval - (monotonic() - start))):
            start = monotonic()
            with lock:
                if self.__updates:
                    persist()

        if self.__updates:
            with lock:
                persist()
        log.debug('Finished')

    def __persist(self):
        try:
            # Update all changed offset as efficiently as possible via batch
            with self.__cache.batched() as batch:
                for asset_id, offset in self.__updates.items():
                    if offset is None:
                        batch.unmark(asset_id)
                    else:
                        batch.put_attr(asset_id, **{self.__offset_field: offset})
        except:
            log.error('Failed to persist to DB', exc_info=DEBUG_ENABLED)
        else:
            log.debug('Persisted %d updates to DB', len(self.__updates))
            self.__updates.clear()

    def clear(self):
        with self.__lock:
            self.__assets.clear()
            self.__updates.clear()
            # Performed here rather than in bg thread as otherwise behaviour might be unexpected from user perspective
            self.__cache.clear()
        return True

    def clear_for(self, asset_id):
        self._validate_asset_id(asset_id)
        with self.__lock:
            self.__updates[asset_id] = None
            self.__assets.pop(asset_id, None)
        return True

    @property
    def count(self):
        return self.__cache.count

    def get_offset(self, asset_id):
        self._validate_asset_id(asset_id)
        try:
            return self.__assets[asset_id]
        except KeyError:
            pass
        log.debug('Fetching offset from cache for %s', asset_id)
        with self.__lock:
            try:
                offset = self.__cache.get_attr(asset_id, self.__offset_field)[self.__offset_field]
            except KeyError:
                offset = self._DEFAULT_OFFSET
            self.__assets[asset_id] = offset

        return offset

    def set_offset(self, asset_id, offset, force=False):
        # asset validated via get_offset call
        self._validate_offset(offset)
        with self.__lock:
            current = self.get_offset(asset_id)

            if offset > current or (force and offset != current):
                self.__updates[asset_id] = offset
                self.__assets[asset_id] = offset

        return True
