# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.


class EventRegistryException(Exception):
    """Raised by registry on encode or decode failure."""
    pass


class UnknownEvent(EventRegistryException):
    """Applicable to both encoding/decoding - event type is not known."""

    def __init__(self, event_type, *args):
        super().__init__(*args)
        self.event_type = event_type


class EventParsingError(EventRegistryException):
    """Generic encode/decode error, specific to an event type"""

    def __init__(self, event_type, version, *args):
        super().__init__(*args)
        self.event_type = event_type
        self.version = version


class UnknownVersion(EventParsingError):
    """Applicable to both encoding/decoding - version is not known."""
    pass


class EncodeDecodeError(EventParsingError):
    """Applicable to both encoding/decoding - avro encoding/decoding failed."""
    pass


class ValidationError(EventParsingError):
    """Additional validation, as defined by event type, has failed."""
    pass
