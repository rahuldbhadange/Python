# Copyright (c) 2019 Iotic Labs Ltd. All rights reserved.


class FollowerException(Exception):
    pass


class ShutdownRequested(FollowerException):
    """Indicates that the current operation cannot complete because the follower has been asked to stop."""


class AssetUnknown(FollowerException):
    """Indicates that the operation cannot be performed because the given asset is not known"""
    pass


class T2Unavailable(FollowerException):
    """Type2 functionality has not been enabled in this follower"""
    pass


class T2Timeout(FollowerException):
    """The response for a type 2 request has timed out"""
    pass


class NotConnected(FollowerException):
    """There currently is no Iotic Space connection to service the request"""


from ..t2.chunked import T2ResponseException  # noqa: F401  pylint: disable=unused-import
