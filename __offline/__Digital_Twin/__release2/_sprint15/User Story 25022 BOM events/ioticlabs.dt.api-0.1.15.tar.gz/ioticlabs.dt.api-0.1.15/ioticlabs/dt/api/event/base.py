# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

"""Event base class and supporting routines"""

from abc import ABCMeta, abstractmethod
from datetime import datetime, timezone

_MIN_DATETIME_NAIVE = datetime.utcfromtimestamp(0)


def field(name, type_, **kwargs):
    """Shorthand for Avro field definitions. Returns dict with given name and type keys and any additional arguments
    specified.
    """
    fld = {'name': name, 'type': type_}
    fld.update(kwargs)
    return fld


class AssetEvent(metaclass=ABCMeta):
    """Base class for asset event types. Covers handling of extra data (schema and validation) and versioning

    Only the abstract methods and optionally _validate_data should be implemented/overloaded. The name of the event is
    derived from the class name itself which must follow camel case and is restriced to ASCII.
    """

    # Defined as class rather than static methods so that implementations are free to use class attributes
    @classmethod
    @abstractmethod
    def _default_version(cls):
        """Must return (non-negative) integer indicating current default version."""
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def _known_versions(cls):
        """Must return mapping of available versions (non-negative integer) to either: Avro (v1.8) schema or None if no
        extra data applies to the version of this event type.

        Notes:
            - Defining an event type which starts with extra data and subsequently has None is not recommended.

            - Record types can also be nested. For a more readable definition, the schema for each version can also be
              defined as a sequence of schemas (and referenced in following definitions). The final schema in the
              sequence is treated as the top-level schema.
            - Names, namespaces and aliases (where defined) will be automatically prefixed to avoid clashing with
              definitions of other version of this event class as well as any other event classes registered. As such
              the null namespace cannot be used and the any custom Avro types are at least relative to implied/internal
              prefix. I.e. schema definitions for each version and event class are completely independent.

        Simple example:

        return {
            1: None
            2: {
                'name': 'MyEventData',
                'type': 'record',
                'fields': [
                    {'name': 'station', 'type': 'string'},
                    # Additional timestamp beyond event time itself
                    {'name': 'last_departure', 'type': 'timestamp-millis'},
                ]
            }
        }

        See also:
            https://avro.apache.org/docs/1.8.2/spec.html
            http://dekarlab.de/wp/?p=489

        """
        raise NotImplementedError

    def _validate_data(self):
        """Overload to define additional validation steps for extra data beyond schema validation (e.g. range of values
        allowed for a field). This will be called after/before encoding/decoding respectively. I.e. at the point of
        call,  extra data can be assumed to be valid with respect to the approriate schema. Any exception raised will
        deem extra data to be invalid. Note: Validation must take versioning into account.
        """
        pass

    def __init__(self, asset, source=None, time=None, systime=None, offset=-1, version=None, data=None):
        """See associated properties for details on parameters. Raises ValueError if any of the paramters are invalid.

        Note:
            Timezone: time/systime are converted to naive UTC equivalents. If they already are naive they are assumed
            to be UTC.
        """
        if not (isinstance(asset, str) and asset):
            raise ValueError('asset')
        self.__asset = asset

        if not ((isinstance(source, str) and source) or source is None):
            raise ValueError('source')
        self.__source = source

        if not (isinstance(offset, int) and offset >= -1):
            raise ValueError('offset')
        self.__offset = offset

        self.__time = self.__check_convert_datetime(time)
        self.__systime = self.__check_convert_datetime(systime)

        if version is None:
            self.__version = self._default_version()
        elif version in self._known_versions():
            self.__version = version
        else:
            raise ValueError('version')

        self.__data = data

    # Used in constructor to validate time & systime as well as normalise to naive instance in UTC
    @staticmethod
    def __check_convert_datetime(time):
        if time is None:
            return None
        if not isinstance(time, datetime):
            raise TypeError('time must be datetime instance')
        if time.tzinfo:
            time = time.astimezone(timezone.utc).replace(tzinfo=None)
        if time < _MIN_DATETIME_NAIVE:
            raise ValueError('Time is before epoch')
        return time

    def __str__(self):
        return "<%s v%d ('%s'@%d)>" % (self.__class__.__name__, self.__version, self.__asset, self.__offset)

    def __repr__(self):
        return '%s(%r, source=%r, time=%r, systime=%r, offset=%r, version=%r, data=%s)' % (
            self.__class__.__name__,
            self.__asset,
            self.__source,
            self.__time,
            self.__systime,
            self.__offset,
            self.__version,
            None if self.__data is None else '...'
        )

    @classmethod
    def name(cls):
        """Name (str) of event type. Must NOT be overridden."""
        return cls.__name__

    @property
    def asset(self):
        """Asset id (str) to which event applies"""
        return self.__asset

    @property
    def source(self):
        """Source of event (str), e.g. an integrator. Can be None when instance has been created for publishing."""
        return self.__source

    @property
    def time(self):
        """Time of event (datetime, naive) in UTC. Can be None when instance has been created for publishing, in which
        case current UTC time will be used. This field has no monotonicity requirement and should be used to store time
        which has a specific meaning to the event. (E.g. document creation time.)
        """
        return self.__time

    @property
    def systime(self):
        """Time of event insertion (datetime, naive) in UTC. Ignored from publishing perspective. Consumed events have
        this set to a monotonically increasing timestamp which indicates when the event was stored in the system. It is
        independent from the time field.
        """
        return self.__systime

    @property
    def offset(self):
        """Offset (int) of event in event stream for this asset. A value of -1 indicates the offset is not applicable,
        i.e. the event instance has been created for publishing.
        """
        return self.__offset

    @property
    def version(self):
        """Version (int) of this type of event (defaults to _default_version()). Used to indicate changes in extra data
        format. Message consumers should explicitly check for event version to ensure they are not blindly consuming
        newer versions in an incompatible manner.
        """
        return self.__version

    @property
    def data(self):
        """Extra data specific to event type and version, or None if not applicable.

        Note:
            - This is the decoded version - encoding/decoding is automated based on applicable version and schema.
            - An Avro schema defining a single primitive null type cannot be distinguished from no extra data at all,
              i.e. both will decode as None.
        """
        return self.__data
