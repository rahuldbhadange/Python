# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

import logging
from abc import ABCMeta, abstractmethod
from collections.abc import Mapping

from ioticlabs.dt.common.defaults import Asset
from ioticlabs.dt.common.util import import_class_item, NestedConfig

log = logging.getLogger(__name__)


class TrackerBase(metaclass=ABCMeta):
    """Responsible for keeping track of asset event stream (next expected) offsets"""

    _DEFAULT_OFFSET = Asset.EventStore.SMALLEST_OFFSET

    @abstractmethod
    def __init__(self, config):
        """Instantiate tracker instance. Should only perform minimal tasks. Use start() to e.g. connect to backing
        store.

        config - mapping of config applicable to particular tracker implementation
        """
        pass

    @classmethod
    def _validate_offset(cls, offset):
        """Convenience method for ensuring the offset is valid. Should be used in any methods shich accept an offset.

        Raises ValueError if invalid, returns True otherwise.
        """
        if not (isinstance(offset, int) and offset >= cls._DEFAULT_OFFSET):
            raise ValueError('Invalid offset: %r' % offset)
        return True

    @staticmethod
    def _validate_asset_id(asset_id):
        """Convenience method for ensuring the asset is valid. Should be used in any methods shich accept an asset_id.
        Note that this only performed primited validation, i.e. requirements by e.g. producer & consumer might be more
        strict.

        Raises ValueError if invalid, returns True otherwise.
        """
        if not (isinstance(asset_id, str) and asset_id):
            raise ValueError('Invalid asset id: %r' % asset_id)
        return True

    def start(self):
        """Override if require setup steps. Will be called before any other methods."""
        pass

    def stop(self, timeout=10):
        """Override if require shutdown steps. Will be called as final method. Once stopped, starting again is not
        supported.
        """
        pass

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop()

    @abstractmethod
    def clear(self):
        """Clear offset store completely. Must be thread safe. Returns True unless did not managed to persist to backing
        store.
        """
        raise NotImplementedError

    @abstractmethod
    def clear_for(self, asset_id):
        """Remove stored offset for given asset. If no offset present, this is a no-op. Must be thread safe. Returns
        True unless did not managed to persist to backing store.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def count(self):
        """Total number of tracked assets."""
        raise NotImplementedError

    @abstractmethod
    def get_offset(self, asset_id):
        """Returns currently stored offset (integer), or _DEFAULT_OFFSET if non is stored. Must be thread safe."""
        raise NotImplementedError

    @abstractmethod
    def set_offset(self, asset_id, offset, force=False):
        """Sets offset for given asset. This should be one larger than the largest handled offset. Must be thread safe.

        asset_id - if of asset for which to store offset
        offset - non-negative integer offset
        force - whether to update offset even if it is not larger than before. If not set, calling this method with such
            an offset will be a no-op.

        Returns True unless did not managed to persist to backing store.
        """
        raise NotImplementedError


def get_tracker(config, warn_no_config=True):
    """Instantiate known asset tracker. If warn_no_config is set, log warning about lack of configuration."""
    method = NestedConfig.get(
        config, 'asset.tracker.method', required=False, check=lambda x: isinstance(x, Mapping) and len(x) == 1
    )
    if method:
        name, config = next(iter(method.items()))
        if not isinstance(config, Mapping):
            raise ValueError('Expecting mapping for tracker method %s config' % name)
    else:
        if warn_no_config:
            log.warning('No tracker method specified, using memory-only one')
        name, config = 'memory', {}

    cls = import_class_item('.tracker.' + name, name.capitalize(), relative_module=__name__)
    if not issubclass(cls, TrackerBase):
        raise TypeError('Unexpected tracker type: %s' % cls)

    return cls(config)
