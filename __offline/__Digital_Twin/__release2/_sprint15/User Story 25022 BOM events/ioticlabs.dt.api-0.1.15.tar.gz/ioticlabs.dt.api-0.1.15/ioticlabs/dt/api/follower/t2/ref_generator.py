# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

from os import urandom
from math import ceil
from threading import Lock


class ReferenceGenerator:
    """Generates unique string ids (thread safe, within runtime of process)"""

    def __init__(self, prefix_len=8):
        if not isinstance(prefix_len, int) and prefix_len >= 2:
            raise ValueError('prefix_len')
        # hex encoding -> only need 'half' for generation from bytes
        self.__prefix = urandom(ceil(prefix_len / 2)).hex()[:prefix_len]
        self.__lock = Lock()
        self.__idx = 0

    def get(self):
        """Get a unique id string (with previously specified prefix)"""
        with self.__lock:
            idx = self.__idx
            self.__idx = idx + 1
            return '%s%d' % (self.__prefix, idx)
