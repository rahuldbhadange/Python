# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

from threading import Lock

from ioticlabs.dt.common.defaults import Asset

from ..event.base import AssetEvent

_SMALLEST_OFFSET = Asset.EventStore.SMALLEST_OFFSET


class SerialiserAssetUnknown(Exception):
    """Raised when AssetEventSerialiser asked to add or retrieve events for an unknown asset."""
    pass


class AssetEventSerialiser:
    """Buffers events by offset such that events can be retrieved in offset order without gaps and repeated events are
    ignored. Thread-safe.
    """

    def __init__(self):
        # Mapping of asset_id to _AssetEvents instance
        self.__assets = {}
        self.__lock = Lock()

    def initialise(self, asset_id, next_offset):
        """Set the next expected offset for the given asset. Returns True unless the asset is already being tracked.

        Raises:
            ValueError if next_offset is invalid. (Note: asset id is not checked as it is only used for internal
                mapping.
        """
        with self.__lock:
            if asset_id in self.__assets:
                return False
            self.__assets[asset_id] = _AssetEvents(next_offset)
        return True

    def clear(self, asset_id=None):
        """Clears event tracking for either all assets or a particular one. If the asset is not known, this is a no-op.
        """
        # No locking required since performing single clear/pop operation
        if asset_id is None:
            self.__assets.clear()
        else:
            self.__assets.pop(asset_id, None)

    def add(self, event):
        """Add an event to the buffer for a particular asset. If the asset is older than the next expected one or the
        given offset is already enqueued, the event it ignored.

        Raises:
            SerialiserAssetUnknown if the given asset has not been initialised yet.
            TypeError if the event is not of the expected type

        Returns: True if at least one event is ready to be retrieved now for this particular asset, False otherwise.
        """
        if not isinstance(event, AssetEvent):
            raise TypeError('event')

        try:
            events = self.__assets[event.asset]
        except KeyError as ex:
            raise SerialiserAssetUnknown(event.asset) from ex

        return events.add(event)

    def retrieve_for(self, asset_id):
        """Iterator over available events for given asset.

        Raises:
            SerialiserAssetUnknown if the given asset has not been initialised yet.
        """
        # No locking required since performing single (get) operation and _AssetEvents is thread-safe itself.
        try:
            events = self.__assets[asset_id]
        except KeyError as ex:
            raise SerialiserAssetUnknown(asset_id) from ex

        yield from events.retrieve()

    def get_next_offset_for(self, asset_id):
        """Returns next expected offset for a given asset.

        Raises:
            SerialiserAssetUnknown if the given asset has not been initialised yet.
        """
        # No locking required since performing single (get) operation and _AssetEvents is thread-safe itself.
        try:
            return self.__assets[asset_id].next_offset
        except KeyError as ex:
            raise SerialiserAssetUnknown(asset_id) from ex


class _AssetEvents:
    """Buffers out-of-order events for serialised in-order consumption. Used by AssetEventSerialiser. Thread-safe."""

    def __init__(self, next_offset):
        """Instantiate a new _AssetEvents object (for a particular asset).

        next_offset - what offset to expect next. Any events passed to add() with an offset smaller than this will be
            ignored.
        """
        if not (isinstance(next_offset, int) and next_offset >= _SMALLEST_OFFSET):
            raise ValueError('next_offset')
        # Last offset handled
        self.__last_offset = next_offset - 1
        # Tuples of (offset, events) sorted by offset. Using a list instead of e.g. deque since, although remove
        # elements from the left, must sort them after each addition.
        self.__events = []
        # Set of buffered event offsets
        self.__offsets = set()
        self.__lock = Lock()

    @property
    def next_offset(self):
        """Offset of next event to be retrieved (once available)."""
        return self.__last_offset + 1

    def add(self, event):
        """Returns True if due to event addition at least one event can be retrieved in order. Events with offsets
        smaller than what is expected are ignored, as are duplicates."""
        if not isinstance(event, AssetEvent):
            raise TypeError('event')
        offset = event.offset
        events = self.__events

        with self.__lock:
            # Ignore old events and already pending offset events
            if offset > self.__last_offset and offset not in self.__offsets:
                # Note: Could just store event but more efficient to sort implicitly by first argument of tuple (offset)
                events.append((offset, event))
                events.sort(key=lambda x: x[0])
                self.__offsets.add(offset)
                # Must compare against oldest event rather than just added one since might have already had a
                # retrievable sequence of events beforehand.
                return events[0][0] == self.__last_offset + 1

        return False

    def retrieve(self):
        """Iterator over available in-order events."""
        events = self.__events
        with self.__lock:
            while events and events[0][0] == self.__last_offset + 1:
                offset, event = events.pop(0)
                self.__offsets.remove(offset)
                self.__last_offset = offset
                yield event
