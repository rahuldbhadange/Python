# Copyright (c) 2019 Iotic Labs Ltd. All rights reserved.

from enum import Enum


class IntegratorException(Exception):
    pass


class AssetUnknown(IntegratorException):
    """The asset applicable to the current operation is no longer known"""
    pass


class ShutdownRequested(IntegratorException):
    """Indicates that the current operation cannot complete because the integrator has been asked to stop."""


class EventPublishFailure(IntegratorException):

    class Reason(Enum):
        REMOTE_TIMEOUT = 'Remote asset twin timed out'
        """Remote asset twin timed out"""
        REMOTE_FAILURE = 'Remote asset twin reported failure'
        """Remote asset twin reported failure"""
        LOCAL_TIMEOUT = 'Iotic Agent timeout'
        """Iotic Agent timed out"""
        NOT_CONNECTED = 'Iotic Agent offline'
        """Iotic Agent is offline"""

    def __init__(self, asset_id, reason):
        if not isinstance(reason, self.Reason):
            raise TypeError('reason')
        self.reason = reason
        super().__init__(asset_id, reason.value)

    @classmethod
    def from_tell_result(cls, asset_id, result):
        return cls(asset_id, cls.Reason.REMOTE_TIMEOUT if result == 'timeout' else cls.Reason.REMOTE_FAILURE)


class T2ResponseFailure(IntegratorException):

    class Reason(Enum):
        LOCAL_TIMEOUT = 'Iotic Agent timeout'
        """Iotic Agent timed out"""
        NOT_CONNECTED = 'Iotic Agent offline'
        """Iotic Agent is offline"""

    def __init__(self, asset_id, reason):
        if not isinstance(reason, self.Reason):
            raise TypeError('reason')
        self.reason = reason
        super().__init__(asset_id, reason.value)
