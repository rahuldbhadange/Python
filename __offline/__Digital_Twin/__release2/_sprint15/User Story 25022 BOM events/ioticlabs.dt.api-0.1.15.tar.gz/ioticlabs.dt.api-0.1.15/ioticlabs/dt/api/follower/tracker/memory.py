# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

from threading import Lock

from . import TrackerBase


class Memory(TrackerBase):
    """In-memory only implementation"""

    def __init__(self, config):
        super().__init__(config)
        # Mapping of asset id to offset
        self.__assets = {}
        self.__lock = Lock()

    def clear(self):
        with self.__lock:
            self.__assets.clear()
        return True

    def clear_for(self, asset_id):
        self._validate_asset_id(asset_id)
        with self.__lock:
            self.__assets.pop(asset_id, None)
        return True

    @property
    def count(self):
        return len(self.__assets)

    def get_offset(self, asset_id):
        self._validate_asset_id(asset_id)
        with self.__lock:
            return self.__assets.get(asset_id, self._DEFAULT_OFFSET)

    def set_offset(self, asset_id, offset, force=False):
        self._validate_asset_id(asset_id)
        self._validate_offset(offset)
        with self.__lock:
            if force or offset > self.__assets.setdefault(asset_id, offset):
                self.__assets[asset_id] = offset
        return True
