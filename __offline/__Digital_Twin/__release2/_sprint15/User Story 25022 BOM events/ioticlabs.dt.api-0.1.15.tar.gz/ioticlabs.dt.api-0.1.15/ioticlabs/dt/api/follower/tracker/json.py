# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

from threading import Lock

from ioticlabs.dt.common.item_cache.json import Json as JsonItemCache

from . import TrackerBase


class Json(TrackerBase):
    """Primitive local file tracker. Assumes this is the only process accessing the tracker."""

    def __init__(self, config):
        super().__init__(config)
        self.__lock = Lock()
        self.__cache = JsonItemCache(config)

    def start(self):
        self.__cache.start()

    def stop(self, timeout=10):
        self.__cache.stop(timeout=timeout)

    def clear(self):
        return self.__cache.clear()

    def clear_for(self, asset_id):
        self._validate_asset_id(asset_id)
        return self.__cache.unmark(asset_id)

    @property
    def count(self):
        return self.__cache.count

    def get_offset(self, asset_id):
        self._validate_asset_id(asset_id)
        try:
            return self.__cache.get_attr(asset_id, 'offset')['offset']
        except KeyError:
            return self._DEFAULT_OFFSET

    def set_offset(self, asset_id, offset, force=False):
        # asset validated via get_offset call
        self._validate_offset(offset)
        with self.__lock:
            current = self.get_offset(asset_id)

            if offset > current or (force and offset != current):
                return self.__cache.mark_as_known(asset_id, offset=offset)

        return True
