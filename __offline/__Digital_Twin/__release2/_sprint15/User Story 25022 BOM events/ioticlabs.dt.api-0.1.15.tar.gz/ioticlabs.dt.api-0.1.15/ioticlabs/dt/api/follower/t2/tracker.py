# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

from threading import Lock
from contextlib import contextmanager
from queue import Queue, Empty

from ..exceptions import T2Timeout, T2ResponseException


class T2ResponseTracker:
    """Provides queueing for synchronous access to type 2 responses. No validation is performed here!"""

    def __init__(self):
        # Mapping of request reference (uref) to queues. Queue elements are all tuples of either (mime, data) or
        # (None, T2ResponseException), where exc is an exception to be re-raised.
        self.__reqs = {}
        self.__lock = Lock()

    @contextmanager
    def wait_for_chunks(self, uref, timeout=None, first_chunk_timeout=None):
        """Yields generator of chunks from response as mime (str), data (bytes) pairs.

        uref - request referenece
        timeout - how long between chunks to wait before timing out
        first_chunk_timeout - how long to wait before first response chunk. If not set, defaults to timeout

        Raises:
            ValueError - if the reference is already being tracker
            T2Timeout - if either timeout or first_chunk_timeout occur
            T2ResponseException - if the request failed due to a provider error
        """
        # Lock here only so guaranteed to catch duplicate urefs
        with self.__lock:
            if uref in self.__reqs:
                raise ValueError('uref')
            self.__reqs[uref] = queue = Queue()
        try:
            yield self.__chunk_iter(queue, timeout, first_chunk_timeout)
        finally:
            self.__reqs.pop(uref, None)

    @staticmethod
    def __chunk_iter(queue, timeout, first_chunk_timeout):
        """chunk generator, used by wait_for_chunks context manager"""
        wait = first_chunk_timeout or timeout
        while True:
            try:
                mime, data_or_exc = queue.get(timeout=wait)
            except Empty as ex:
                raise T2Timeout from ex
            # See also add_chunk_for, is_finished & add_exception
            if mime is None:
                # EOF
                if data_or_exc is None:
                    break
                # Exception occurred
                else:
                    raise data_or_exc
            else:
                # Normal chunks
                yield mime, data_or_exc

            # Switch to non-first timeout
            wait = timeout

    def add_chunk_for(self, uref, mime, data):
        """Enqueues chunk if expecting, ignores otherwise"""
        # Usage of None for mime param reserved to pass exceptions
        if not isinstance(mime, str):
            raise TypeError('mime')
        # Usage of None for data param reserved to signal EOF
        if data is None:
            raise TypeError('data')
        try:
            self.__reqs[uref].put((mime, data))
        except KeyError:
            pass

    def is_finished(self, uref):
        """Mark the request as finished if exists, ignore otherwise"""
        try:
            self.__reqs[uref].put((None, None))
        except KeyError:
            pass

    def add_exception(self, exc):
        """Enqueues T2ResponseException for response (with particular uref within)"""
        if not isinstance(exc, T2ResponseException):
            raise TypeError('exc')
        try:
            self.__reqs[exc.uref].put((None, exc))
        except KeyError:
            pass
