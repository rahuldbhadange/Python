# Copyright (c) 2019 Iotic Labs Ltd. All rights reserved.

from io import BytesIO
from math import ceil
from functools import partial
import logging

from lz4framed import (  # noqa: F401 pylint: disable=unused-import
    decompress, Compressor, Lz4FramedError as CompressionError, LZ4F_BLOCKSIZE_MAX64KB
)

from ioticlabs.dt.common.util import positive_int

log = logging.getLogger(__name__)


def _memoryview_iter(view, size):
    """generator yielding sub-views of the given memoryview and size. Does not check whether the view is read-only or
    call release() on it.
    """
    if not isinstance(view, memoryview):
        raise TypeError('view')
    if not positive_int(size):
        raise ValueError('size')
    for i in range(ceil(len(view) / size)):
        yield view[(i * size):((i + 1) * size)]


class FixedSizeCompressor:
    """Provides means to compress into fixed length chunks (LZ4 frames). If compressed result exceeds the maximum size,
    uncompressed chunks also not exceeding the given maximum size will be generated instead. WARNING: This class does
    NOT perform any validation and is NOT thread safe.

    Once instantiated, one or more calls to write() should be followed by a final call to finish().
    """

    def __init__(self, max_size, add_size=(1024 * 4)):
        """
        max_size - maximum permissible size of each (un)compressed chunk in bytes
        add_size - how many bytes to feed into lz4 compressor at a time. Smaller values can result in more of max_size
            being utilised.
        """
        if max_size < add_size * 2:
            raise ValueError('max_size must be at least twice as large as add_size')
        self.__max_size = max_size
        self.__add_size = add_size
        # Buffer of uncompressed data since last compressed chunk (in case compressed output exceeds max_size)
        self.__uncompressed = BytesIO()
        self.__compressed = BytesIO()
        self.__make_compressor = partial(Compressor, block_size_id=LZ4F_BLOCKSIZE_MAX64KB, autoflush=True)
        self.__compressor = self.__make_compressor(self.__compressed)

    def write(self, bytes_):
        """Adds the given raw data (a bytes-like object) to the currently compressed partial chunk. Returns sequence of
        zero or more tuples of (chunk, whether_chunk_compressed).
        """
        compressor = self.__compressor
        compressed = self.__compressed
        uncompressed = self.__uncompressed
        max_size = self.__max_size
        threshold = max_size - self.__add_size
        chunks = []

        for add_raw in _memoryview_iter(memoryview(bytes_), self.__add_size):
            # This should never raise Lz4FramedNoDataError since _memoryview_iter should never yield empty sub-views
            compressor.update(add_raw)
            uncompressed.write(add_raw)

            if compressed.tell() >= threshold:
                # Flush remaining partial data & finish lz4 frame
                compressor.end()

                if compressed.tell() <= max_size:
                    chunks.append((compressed.getvalue(), True))
                else:
                    chunks.extend(
                        (plain.tobytes(), False) for plain in _memoryview_iter(uncompressed.getbuffer(), max_size)
                    )
                    log.warning('Compressed output too large, outputting as uncompressed chunk(s)')

                # Reset input/output buffers to handle more data
                uncompressed.close()
                compressed.close()
                self.__uncompressed = uncompressed = BytesIO()
                self.__compressed = compressed = BytesIO()
                self.__compressor = compressor = self.__make_compressor(compressed)

        return chunks

    def finish(self):
        """Returns any remaining data and completes this compressors. Has same return type as write(). After this method
        has been called, this instance is no longer useable.
        """
        compressed = self.__compressed
        max_size = self.__max_size

        self.__compressor.end()
        self.__compressor = None
        if compressed.tell() <= max_size:
            chunks = [(compressed.getvalue(), True)]
        else:
            chunks = [(plain.tobytes(), False) for plain in _memoryview_iter(self.__uncompressed.getbuffer(), max_size)]
            log.warning('Compressed output too large (final), handling as uncompressed chunk(s)')

        compressed.close()
        self.__uncompressed.close()
        # Ensure more calls to write/finish fail since should no longer be usable
        self.__compressor = None

        return chunks


# Part of sanity-test tool
def _parse_args():
    from argparse import ArgumentParser, ArgumentTypeError

    def pos_int(value):
        value = int(value)
        if not positive_int(value):
            raise ArgumentTypeError('not a positive integer')
        return value

    parser = ArgumentParser(
        description="""Chunked compression test tool. Compresses the given input, displays stats about chunks and
        calculates SHA1 sum for both original input and decompressed output.
        """
    )
    parser.add_argument(
        'input', metavar='INPUT_FILE', nargs='?', help='File to compress. If not specified, stdin will be used.'
    )
    parser.add_argument(
        '-s', '--chunk-size', metavar='MAX_CHUNK_SIZE', type=pos_int, default=(126 * 1024),
        help='Maximum size of each (un)compressed chunk in bytes',
    )
    parser.add_argument(
        '-a', '--add-size', metavar='ADD_SIZE', type=pos_int,
        help="""How many bytes to feed into lz4 compressor at a time. Smaller values can result in more of
        MAX_CHUNK_SIZE being utilised.
        """
    )
    return parser.parse_args()


# Part of sanity-test tool - compresses from the given read function and produces chunk usage & compression stats
def _do_compression(args, read_func):
    from hashlib import sha1

    compressor = FixedSizeCompressor(args.chunk_size, **({'add_size': args.add_size} if args.add_size else {}))
    read_size = args.chunk_size * 2
    hash_in = sha1()
    hash_out = sha1()
    chunks = 0
    chunks_compressed = 0
    data_len = 0
    chunk_len = 0

    while True:
        data = read_func(read_size)
        if not data:
            break
        data_len += len(data)
        hash_in.update(data)
        for chunk, compressed in compressor.write(data):
            hash_out.update(decompress(chunk) if compressed else chunk)
            chunks += 1
            chunks_compressed += compressed
            chunk_len += len(chunk)

    for chunk, compressed in compressor.finish():
        hash_out.update(decompress(chunk) if compressed else chunk)
        chunks += 1
        chunks_compressed += compressed

    # Should not happen
    if hash_in.hexdigest() != hash_out.hexdigest():
        raise ValueError('Unexpected SHA1 mismatch (in/out): %s / %s' % (hash_in.hexdigest(), hash_out.hexdigest()))

    print("""
    Input:\t\t%s
    Total chunks:\t%d
    Compressed chunks:\t%d (%.1f%%)
    Data total:\t\t%d bytes
    Chunk total:\t%d bytes (%.1f%%)
    Max chunk size:\t%d bytes
    Avg. chunk size:\t%.0f bytes (%.1f%% of max)
    SHA1: %s
    """ % (
        args.input if args.input else 'STDIN',
        chunks,
        chunks_compressed, (chunks_compressed / chunks * 100),
        data_len,
        chunk_len, (chunk_len / data_len * 100),
        args.chunk_size,
        chunk_len / chunks, (chunk_len / chunks / args.chunk_size * 100),
        hash_out.hexdigest()
    ))


def _main():
    args = _parse_args()
    if args.input:
        with open(args.input, 'rb') as in_file:
            _do_compression(args, in_file.read)
    else:
        from sys import stdin
        _do_compression(args, stdin.buffer.read)


if __name__ == '__main__':
    _main()
