# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

"""Wrappers for T2 requests & responses (including reassembly)"""

import logging
from collections import namedtuple
from threading import Lock

from ioticlabs.dt.common.values.t2 import (
    get_t2_template_for_dt_req, get_t2_template_for_p_rsp, get_t2_template_for_r_req, T2_VALUES_RSP_PROVIDER,
    T2_VALUES_RSP_DT, T2Mime, T2ProviderFailureReason, T2ReqFailureReason
)
from ioticlabs.dt.common.util import non_empty_str, non_negative_int, valid_guid

from .compression import decompress, CompressionError

log = logging.getLogger(__name__)
DEBUG_ENABLED = log.isEnabledFor(logging.DEBUG)

# Relying on this for using T2Response class below
assert T2_VALUES_RSP_PROVIDER == T2_VALUES_RSP_DT, 'provider and twin responses not the same'


class T2Request(namedtuple('T2Request', 'asset_id uref type_ cb_guid data')):
    """Type 2 request from a requestor.

    asset_id - asset to which request applies
    uref - originating reference (used in response to this request)
    type_ - type of request
    cb_guid - callback control to which to send response
    data - Data specific to the type of request
    """

    __slots__ = ()

    def __new__(cls, asset_id, uref, type_, cb_guid, data):
        if not (
                all(non_empty_str(item) for item in (uref, type_)) and
                valid_guid(cb_guid) and
                ((isinstance(data, bytes) and data) or data is None)
        ):
            raise ValueError('Invalid request arguments')

        return super().__new__(cls, asset_id, uref, type_, cb_guid, data)

    @classmethod
    def from_control_args(cls, control_args):
        """Used to construct from incoming control request (from asset/twin). Will except if arguments are invalid."""
        values = get_t2_template_for_dt_req(data=control_args['data']).values
        return cls(values.asset, values.uref, values.type, values.cb_guid, values.data)

    def to_requestor_request(self):
        """Returns template populated with T2_VALUES_REQ_REQUESTOR values"""
        return get_t2_template_for_r_req(data={
            'uref': self.uref,
            'type': self.type_,
            'cb_guid': self.cb_guid,
            'data': self.data
        })


class T2Response(namedtuple('T2Response', 'uref mime mime_data data seq last')):
    """Type 2 response (chunk) from asset/twin, as passed to internal workers. Most arguments map to T2_VALUE
    definitions.

    uref - T2_VALUE_UREF
    cb_guid - control guid (of requestor) to forward response to
    mime - control request mime type (T2Mime)
    mime_data - T2_VALUE_MIME
    data - T2_DATA (bytes, encoding depends on mime_data, can be zero length)
    seq - T2_VALUE_SEQ (always zero if mime == T2Mime.ERROR)
    last - T2_VALUE_LAST (always True if mime == T2Mime.ERROR)
    """

    __slots__ = ()

    def __new__(cls, uref, mime, mime_data, data, seq, last):
        if not (
                non_empty_str(uref) and
                isinstance(mime, T2Mime) and
                non_negative_int(seq) and
                isinstance(last, bool)
        ):
            raise ValueError('Invalid response arguments')

        if mime == T2Mime.ERROR:
            if not (last and seq == 0 and mime_data is None):
                # Not expecting error responses after have started sending chunks
                raise ValueError('Invaild seq/last/mime_data for error response')
            # Will raise ValueError. Note: T2ReqFailureReason is a super set of T2ProviderFailureReason
            data = T2ReqFailureReason(data)
        else:
            if not (
                    non_empty_str(mime_data) and
                    isinstance(data, bytes)
            ):
                raise ValueError('Invalid response data/mime (for chunk)')

        return super().__new__(cls, uref, mime, mime_data, data, seq, last)

    @classmethod
    def from_control_args(cls, control_args):
        """Use control request to construct response (from twin). Raises ValueError if arguments are invalid."""
        # will raise ValueError
        values = get_t2_template_for_p_rsp(raw=control_args['data']).values
        return cls(values.uref, T2Mime(control_args['mime']), values.mime, values.data, values.seq, values.last)

    def to_provider_response(self):
        """Return tuple of mime and encoded template populated with T2_VALUES_RSP_PROVIDER values"""
        return (
            self.mime,
            get_t2_template_for_p_rsp(data={
                'uref': self.uref,
                'mime': self.mime_data,
                'data': self.data,
                'seq': self.seq,
                'last': self.last
            }).to_raw()
        )

    @classmethod
    def from_request_with_data(cls, req, mime, data, seq, last, compressed):
        if not isinstance(req, T2Request):
            raise TypeError('req')
        return cls(req.uref, T2Mime.CHUNK_LZ4F if compressed else T2Mime.CHUNK, mime, data, seq, last)

    @classmethod
    def from_request_with_error(cls, req, reason):
        if not isinstance(req, T2Request):
            raise TypeError('req')
        if not isinstance(reason, T2ProviderFailureReason):
            raise TypeError('reason')
        return cls(req.uref, T2Mime.ERROR, None, reason, 0, True)


class ChunkedResponse:
    """Used to re-assemble a chunked T2 response.

    One can either
        - Retrieve the fully re-assembled request via reassembled_data() after checking complete & valid OR
        - Use the available_chunks generator to pass on as much data as is already available (in order) and check
            whether complete is set after exhausting the generator
    """

    def __init__(self, chunk):
        if not isinstance(chunk, T2Response):
            raise TypeError('chunk')
        self.__chunks = {chunk.seq: self.__data_from_chunk(chunk)}
        self.__uref = chunk.uref
        self.__mime_data = chunk.mime_data
        # Smallest expected offset
        self.__next = 0
        # Largest expected offsets
        self.__last = chunk.seq if chunk.last else -1
        self.__lock = Lock()

    @staticmethod
    def __data_from_chunk(chunk):
        if chunk.mime == T2Mime.CHUNK_LZ4F:
            try:
                return decompress(chunk.data)
            except CompressionError as ex:
                raise ValueError('cannot uncompress chunk %d for %s' % (chunk.seq, chunk.uref)) from ex
        if chunk.mime == T2Mime.CHUNK:
            return chunk.data
        # Not expecting to deal with errors in reassembly
        raise ValueError('unexpected chunk mime %s' % chunk.mime)

    def add_chunk(self, chunk):
        """Passing arguments from an unrelated request will raise ValueError. Unexpected chunks will be ignored."""
        if not isinstance(chunk, T2Response):
            raise TypeError('chunk')
        if chunk.uref != self.__uref:
            raise ValueError('uref')

        with self.__lock:
            if chunk.seq < self.__next:
                log.warning('Ignoring chunk %d before smallest offset %d for %s', chunk.seq, self.__next, chunk.uref)
                return
            if self.__last >= 0 and chunk.seq > self.__last:
                log.warning(
                    'Ignoring chunk %d after last expected offset %d for %s', chunk.seq, self.__next, chunk.uref
                )
                return
            self.__chunks[chunk.seq] = self.__data_from_chunk(chunk)
            if chunk.last:
                self.__last = chunk.seq

    @property
    def valid(self):
        """Whether request has all expected chunks available."""
        chunks = self.__chunks
        with self.__lock:
            return (
                len(chunks) == (self.__last - self.__next) + 1 and
                all(seq in chunks for seq in range(self.__next, self.__last))
            )

    @property
    def complete(self):
        """Request reassembled or now invalid. Use `valid` to check which applies."""
        with self.__lock:
            log.debug('complete - n=%d l=%d c=%d', self.__next, self.__last, len(self.__chunks))
            return self.__last >= 0 and len(self.__chunks) >= (self.__last - self.__next) + 1

    @property
    def available(self):
        """Set if expecting available_chunks generator to provide at least one chunk"""
        with self.__lock:
            return self.__next in self.__chunks

    @property
    def uref(self):
        return self.__uref

    @property
    def mime_data(self):
        """Mime of data within chunk (i.e. not T2Mime)"""
        return self.__mime_data

    def available_chunks(self):
        """Generator which returns any available chunks (raw bytes) in order. Automatically updates expected offsets
        and removes handled chunks such that complete/valid are set once enough remaining chunks are available."""
        chunks = self.__chunks
        lock = self.__lock

        while True:
            with lock:
                try:
                    chunk = chunks.pop(self.__next)
                except KeyError:
                    log.debug('No chunks at %d', self.__next)
                    break
                self.__next += 1
                # Allow for other chunks to be added whilst user processes current one
                lock.release()
                try:
                    yield chunk
                finally:
                    lock.acquire()

    def reassembled_data(self):
        """Returns re-assembled data in order of chunks. If available_chunks has been called before, this will contain
        any remaining data only. WARNING: No checking performed, i.e. must check first whether complete & valid.
        """
        chunks = self.__chunks
        # Probably should not need lock since no more chunks expected
        with self.__lock:
            return b''.join(chunks[seq] for seq in sorted(self.__chunks.keys()))
