# Copyright (c) 2018 Iotic Labs Ltd. All rights reserved.

"""Type2 request functionality for integrators (providers) and followers"""
