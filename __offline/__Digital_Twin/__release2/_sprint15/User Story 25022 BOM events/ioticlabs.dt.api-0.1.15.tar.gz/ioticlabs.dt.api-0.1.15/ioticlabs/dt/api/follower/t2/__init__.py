# Copyright (c) 2019 Iotic Labs Ltd. All rights reserved.

import logging

from IoticAgent.IOT.Exceptions import IOTUnknown, IOTSyncTimeout, LinkException, LinkShutdownException

from ioticlabs.dt.common.defaults import T2Requestor
from ioticlabs.dt.common.values.t2 import T2_VALUES_RSP_DT, T2ReqFailureReason

from ...util import log_exceptions
from ...t2.chunked import LargeResponse
from ...t2.wrappers import T2Request
from ..exceptions import T2Timeout, T2ResponseException, AssetUnknown, ShutdownRequested, NotConnected

from .ref_generator import ReferenceGenerator
from .tracker import T2ResponseTracker

log = logging.getLogger(__name__)
DEBUG_ENABLED = log.isEnabledFor(logging.DEBUG)

# Only one needed even if have multiple follower instances
_REFERENCE_GENERATOR = ReferenceGenerator()


class T2Handler:
    """Responsible for making T2 requests. Not responsible for tracking all assets. Since this is for internal use, only
    limited validation is performed.
    """

    def __init__(self, thing):
        """Expecting follower's thing to which to add T2 response control to"""
        # For T2 response chunk access in synchronous way by user
        self.__t2_rsp_tracker = T2ResponseTracker()
        self.__t2_rsp_control_guid = self.__setup_type2_requestor(thing, self.__cb_t2_rsp)

    @staticmethod
    def __setup_type2_requestor(thing, control_cb):
        """Configured control to receive type2 responses (as requestor)"""
        log.info('Type2 requests will be enabled')
        # Local control to which responses are to be sent
        control = thing.create_control(T2Requestor.Point.T2.RSP_LID, callback=control_cb)
        with control.get_meta() as meta:
            meta.set_label(T2Requestor.Point.T2.RSP_LABEL)

        for value in T2_VALUES_RSP_DT:
            control.create_value(value.label, vtype=value.type_, unit=value.unit, description=value.description)

        return control.guid

    def t2_request(self, asset_id, t2_req_control, type_, data, timeout, chunk_timeout):
        """Makes a type 2 request for the given asset. Generates tuples of response mime type and raw data (bytes). See
        see :py:meth:`~ioticlabs.dt.api.follower.Follower.t2_request` for more detailed documentation.

        asset_id - asset to which request applies
        t2_req_control - RemoteControl on asset to which to submit request

        Raises:
            AssetUnknown - if the asset is not known to this follower
            ValueError - if either of the timeouts are invalid
            ShutdownRequested - If shutdown is requested before this request has completed
            T2ResponseException - if request failed to due a provider-related issue
            T2Timeout - if the request could not be completed within the specified timeout
            NotConnected - There currently is no Iotic Space connection to service the request
        """
        for item in (timeout, chunk_timeout):
            if not (isinstance(item, (int, float)) and item > 2):
                raise ValueError('timeout/chunk_timeout must greater than 2')

        uref = _REFERENCE_GENERATOR.get()
        with self.__t2_rsp_tracker.wait_for_chunks(uref, timeout=chunk_timeout, first_chunk_timeout=timeout) as chunks:

            try:
                result = t2_req_control.tell(
                    T2Request(asset_id, uref, type_, self.__t2_rsp_control_guid, data).to_requestor_request(),
                    timeout=timeout
                )
            except IOTUnknown as ex:
                raise AssetUnknown(asset_id) from ex
            except LinkShutdownException as ex:
                raise ShutdownRequested from ex
            except LinkException as ex:
                raise NotConnected from ex
            except IOTSyncTimeout as ex:
                raise T2Timeout from ex

            # synchronous tell response
            if result is not True:
                if result == 'timeout':
                    raise T2Timeout
                else:
                    raise T2ResponseException(uref, T2ReqFailureReason.PROVIDER_UNAVAILABLE)

            yield from chunks

    # @LargeResponse.cb_large_payload is also available but first buffers the whole response before this callback is
    # triggered. Using streamed wrapper so can forward individual chunks to user.
    @log_exceptions(log)
    @LargeResponse.cb_large_payload_streamed
    def __cb_t2_rsp(self, args):
        exc = args.get('exc')
        if exc:
            if isinstance(exc, T2ResponseException):
                log.debug('T2 response error for %s', exc.uref)
                self.__t2_rsp_tracker.add_exception(exc)
            else:
                # Unexpected error bubbled up
                raise exc
        else:
            log.debug('T2 response chunk for %s', args['uref'])
            # Empty data indicates EOF
            if args['data']:
                self.__t2_rsp_tracker.add_chunk_for(args['uref'], args['mime'], args['data'])
            else:
                self.__t2_rsp_tracker.is_finished(args['uref'])
