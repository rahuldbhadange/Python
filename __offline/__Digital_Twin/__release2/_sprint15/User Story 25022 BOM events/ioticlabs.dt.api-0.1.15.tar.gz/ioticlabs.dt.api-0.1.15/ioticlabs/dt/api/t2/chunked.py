# Copyright (c) 2019 Iotic Labs Ltd. All rights reserved.

"""Provides T2 response chunking and reassembly, either streamed or as single 'blob'."""

import logging
from functools import wraps
from time import monotonic
from threading import Lock
from contextlib import contextmanager

from IoticAgent.IOT import Client as IOTClient
from IoticAgent.IOT.RemotePoint import RemoteControl

from ioticlabs.dt.common.values.t2 import (  # noqa: F401
    T2_VALUES_RSP_PROVIDER, T2_VALUES_RSP_DT, T2Mime, T2ReqFailureReason
)
from ioticlabs.dt.common.util import non_empty_str, last_iter

from .wrappers import ChunkedResponse, T2Request, T2Response
from .compression import FixedSizeCompressor

log = logging.getLogger(__name__)
DEBUG_ENABLED = log.isEnabledFor(logging.DEBUG)

# Relying on this for using T2Response class below
assert T2_VALUES_RSP_PROVIDER == T2_VALUES_RSP_DT, 'provider and twin responses not the same'


class T2ResponseException(Exception):
    """Raised for error responses for a type 2 request.

    Args:
        uref: Request reference
        reason (T2ReqFailureReason): One of T2ReqFailureReason
    """

    def __init__(self, uref, reason):
        super().__init__()
        self.uref = uref
        self.reason = T2ReqFailureReason(reason)


class ChunkedRequestTracker:
    """Thread safe chunked request tracker. Thread safe."""

    def __init__(self):
        self.__reqs = {}
        self.__lock = Lock()

    def add_raw(self, control_args):
        """Adds a chunk to the tracker.

        Raises:
            T2ResponseException if a remote error is signalled

        Returns: ChunkedRequest instance if said chunk completes a request, None otherwise
        """
        try:
            chunk = T2Response.from_control_args(control_args)
        except:
            log.warning('Invalid chunked request part, ignoring', exc_info=DEBUG_ENABLED)
            return None

        if chunk.mime == T2Mime.ERROR:
            # Not expecting any more data
            with self.__lock:
                self.__reqs.pop(chunk.uref, None)
            raise T2ResponseException(chunk.uref, chunk.data)

        uref = chunk.uref
        with self.__lock:
            try:
                req = self.__reqs[uref]
            except KeyError:
                self.__reqs[uref] = req = ChunkedResponse(chunk)
            else:
                req.add_chunk(chunk)

            if req.complete:
                del self.__reqs[uref]
                if req.valid:
                    return req
                log.warning('Invalid request %s, ignoring', req.uref)

        return None

    def add_raw_streamed(self, control_args):
        """Similar to add_raw, except returns tuple of uref & mime (of payload) if at least one chunk is available, a
        tuple of (None, None) otherwise. One can subsequently use get_available_chunks(uref) generator to retrieve said
        chunks.

        Raises:
            T2ResponseException if a remote error is signalled
        """
        try:
            chunk = T2Response.from_control_args(control_args)
        except:
            log.warning('Invalid chunked request part, ignoring', exc_info=DEBUG_ENABLED)
            return None, None

        if chunk.mime == T2Mime.ERROR:
            # Not expecting any more data
            with self.__lock:
                self.__reqs.pop(chunk.uref, None)
            raise T2ResponseException(chunk.uref, chunk.data)

        uref = chunk.uref
        with self.__lock:
            try:
                req = self.__reqs[uref]
            except KeyError:
                self.__reqs[uref] = req = ChunkedResponse(chunk)
            else:
                req.add_chunk(chunk)

        return (req.uref, req.mime_data) if req.available else (None, None)

    def get_available_chunks(self, uref):
        """Yields raw (bytes) chunks for a request with the given reference. A final empty chunk indicates the request
        is finished.
        """
        with self.__lock:
            try:
                req = self.__reqs[uref]
            except KeyError:
                return
            yield from req.available_chunks()

            if req.complete:
                log.debug('Request %s complete, removing', uref)
                del self.__reqs[uref]
                if req.valid:
                    yield b''
                # Should not happen as implies that got chunks past 'last' one. Prefer to time out here so error raised
                # rather than ending with incomplete response.
                else:
                    log.warning('Invalid request %s, ignoring', req.uref)


class LargeResponse:
    """Represents an individual T2 response to be transmitted in chunks. Also provides class methods for receiving and
    reassembling such responses. NOT thread safe unless explicitly specified (apart from instantiation itself).
    """

    def __init__(self, rsp_control, req, mime, max_chunk_size):
        """Create a new (large) response request

        rsp_control - RemoteControl instance to send response to
        req - original T2 request
        mime - mime type of data to be sent
        max_chunk_size - how large output chunks should at most be (in bytes). Should be fractionally smaller than the
        transport permits (e.g. Iotic Space QAPI).
        """
        if not isinstance(rsp_control, RemoteControl):
            raise TypeError('remote_control')
        if not isinstance(req, T2Request):
            raise TypeError('req')
        if not non_empty_str(mime):
            raise ValueError('mime')
        self.__rcontrol = rsp_control
        self.__req = req
        self.__mime_data = mime
        self.__compressor = FixedSizeCompressor(max_chunk_size)
        # Iotic request references for chunks (tuple of start time & async req)
        self.__chunk_reqs = []

    @classmethod
    def cb_large_payload(cls, func):
        """Expected to wrap a control (unparsed) callback. Ignores any unrelated requests (i.e. with wrong mime type)
        whilst re-assembling LargePayloadControl-sent ones before forwarding those. Re-assembled requests also include
        the `uref` field with user reference which can be used to determine which request the callback is for. This
        method is thread safe.

        If a failure response is encountered, the `exc` field will be included with an instance of T2ResponseException
        """
        tracker = ChunkedRequestTracker()

        @wraps(func)
        def wrapper(*args, **kwargs):
            # Expecting last positional argument to be 'args' for control callback
            *_, req_args = args

            try:
                req = tracker.add_raw(req_args)
            except T2ResponseException as ex:
                req = None
                req_args['exc'] = ex

            if not req:
                if 'exc' in req_args:
                    # Propagate failure
                    func(*args, **kwargs)
                # Request not complete yet (or failed)
                return

            log.debug('Req %s complete', req.uref)
            req_args['mime'] = req.mime_data
            req_args['uref'] = req.uref
            req_args['data'] = req.reassembled_data()

            func(*args, **kwargs)

        return wrapper

    @classmethod
    def cb_large_payload_streamed(cls, func):
        """Expected to wrap a control (unparsed) callback. Ignores any unrelated requests whilst providing chunks of
        LargePayloadControl-sent ones. This method is thread safe.

        Chunks are provided in order and a final chunk with empty 'data' signals completion. It is the responsibility of
        the caller to re-assemble (or stream) the output, routed based on `uref`.
        """
        tracker = ChunkedRequestTracker()

        @wraps(func)
        def wrapper(*args, **kwargs):
            # Expecting last positional argument to be 'args' for control callback
            *_, req_args = args

            try:
                uref, mime_data = tracker.add_raw_streamed(req_args)
            except T2ResponseException as ex:
                uref = mime_data = None
                req_args['exc'] = ex

            if not uref:
                if 'exc' in req_args:
                    # Propagate failure
                    func(*args, **kwargs)
                # Chunks not available
                return

            log.debug('Req %s chunk(s) available', uref)
            for chunk in tracker.get_available_chunks(uref):
                log.debug('Getting chunk from tracker')
                req_args['mime'] = mime_data
                req_args['uref'] = uref
                req_args['data'] = chunk
                func(*args, **kwargs)

        return wrapper

    @contextmanager
    def writer(self, wait=True):
        """Context manager for streaming write which yields a write(bytes) method. Usage:

        with LargeResponse(...).writer() as write:
            for chunk in some_data_stream:
                write(chunk)

        wait - whether to wait for send requests to complete

        Note: write() method Returns True unless zero-length data was supplied.
        """
        if not self.__compressor:
            raise ValueError('Request completed, cannot restart')
        try:
            yield self.__write
        except:
            self.__compressor = None
            raise

        self.__handle_chunks(final=True)
        if wait:
            self.__wait_for_reqs()

    def send(self, data, wait=True):
        """Synchronously split input into multiple chunks and send all in one go. See also writer().

        data - the raw data (bytes) to send
        wait - whether to wait for send requests to complete
        """
        if not self.__compressor:
            raise ValueError('Response completed, cannot use to send')
        if not isinstance(data, bytes):
            raise TypeError('data')
        # Can happen when mix context manager with this method
        if self.__chunk_reqs:
            raise ValueError('Response already started, cannot use to send')

        self.__handle_chunks(data, final=True)
        if wait:
            self.__wait_for_reqs()

    def __write(self, data):
        """Returns False if provided data is zero length."""
        if not self.__compressor:
            raise ValueError('Request completed, cannot add more data')
        if not data:
            # no data, ignore
            return False
        self.__handle_chunks(data)
        return True

    def __handle_chunks(self, data=None, final=False):
        """Send any pending chunks based on buffered data. If final is set, send all remaining data and treat as
        completed. If neither data nor final is set, this is a no-op.
        """
        if data:
            for chunk, compressed in self.__compressor.write(data):
                self.__send_chunk(chunk, compressed)
        if final:
            last = None
            for last, (chunk, compressed) in last_iter(self.__compressor.finish()):
                self.__send_chunk(chunk, compressed, last=last)

            # Should not happen - finalising compressinog should yield at most one more chunk
            if last is None:
                log.warning('Compressor did not provide final chunk, adding empty one for %s', self.__req.uref)
                self.__send_chunk(b'', False, last=True)

            log.debug('Finished submitting %s', self.__req.uref)
            self.__compressor = None

    def __send_chunk(self, chunk, compressed, last=False):
        """Used by __handle_chunks exclusively. Sends given chunk and adds as pending request to internal chunk request
        list.
        """
        seq = len(self.__chunk_reqs)
        log.debug('Sending chunk %d (final=%s)', seq, last)
        mime, raw_payload = T2Response.from_request_with_data(
            self.__req, self.__mime_data, chunk, seq, last, compressed
        ).to_provider_response()
        # Request asynchronous send (ask) together with time so can wait at most 'timeout' amount of time relative to
        # when request was sent rather than a fixed amount per request.
        self.__chunk_reqs.append((monotonic(), self.__rcontrol.ask_async(raw_payload, mime=mime)))

    def __wait_for_reqs(self):
        timeout = self.__rcontrol._client.sync_timeout

        log.debug('Waiting for %d reqs to finish for %s', len(self.__chunk_reqs), self.__req.uref)
        for start, req in self.__chunk_reqs:
            if timeout:
                req.wait(max(0, timeout - (monotonic() - start)))
            else:
                req.wait()
            IOTClient._except_if_failed(req)
        log.debug('All reqs for %s finished', self.__req.uref)
