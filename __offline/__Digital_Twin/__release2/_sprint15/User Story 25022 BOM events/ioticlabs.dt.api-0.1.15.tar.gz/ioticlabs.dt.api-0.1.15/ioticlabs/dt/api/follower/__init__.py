# Copyright (c) 2019 Iotic Labs Ltd. All rights reserved.

import logging
from time import monotonic
from datetime import datetime
from threading import Thread, Event
from collections import namedtuple, deque
from collections.abc import Mapping
from concurrent.futures import as_completed
from itertools import chain
from functools import partial
from abc import ABCMeta, abstractmethod

from IoticAgent.IOT import Client, DescribeScope
from IoticAgent.IOT.RemotePoint import RemoteControl
from IoticAgent.IOT.Exceptions import IOTUnknown, IOTAccessDenied, LinkShutdownException
from IoticAgent.Core.Const import M_RESOURCE, R_SUB

from ioticlabs.dt.common.discovery import DiscoveryConfig, get_asset_points_for_thing
from ioticlabs.dt.common.scheduler import ScheduledPool
from ioticlabs.dt.common.values.es import (
    ES_VALUES_FOR_REPLAY, get_es_template_for_replay_req, get_es_template_for_feed, get_es_template_for_replay
)
from ioticlabs.dt.common.values.t2 import T2ReqFailureReason  # noqa: F401
from ioticlabs.dt.common.meta import ThingMeta, search_iter
from ioticlabs.dt.common.util import NestedConfig, in_own_thread_single
from ioticlabs.dt.common.util.agent import get_agent_status, AgentStatus  # noqa: F401

from ..event.base import AssetEvent
from ..event.internal import (
    IoticInternalTwinEvent, IntFollowerEventInvalid, IntTwinEventInvalid, IntFollowerStartReplay, SOURCE_IOTIC_INTERNAL
)
from ..event.registry import (
    load_event_registry, UnknownEvent, UnknownVersion, EncodeDecodeError, ValidationError
)
from .tracker import get_tracker
from .event_serialiser import AssetEventSerialiser, SerialiserAssetUnknown
from .exceptions import (  # noqa: F401
    FollowerException, AssetUnknown, T2Unavailable, T2Timeout, T2ResponseException, ShutdownRequested, NotConnected
)

from .t2 import T2Handler

log = logging.getLogger(__name__)
DEBUG_ENABLED = log.isEnabledFor(logging.DEBUG)


class FollowerCallbacks(metaclass=ABCMeta):
    """Set of callbacks which follower implementations must provide.

    Note:
        Methods herein should not perform long-running tasks and instead delegate to make necessary changes.
    """

    @abstractmethod
    def on_asset_created(self, asset_id):
        """A new asset has been created. Called once for each known asset on startup as well as whenever a new asset
        appears whilst the follower is running.
        """
        raise NotImplementedError

    @abstractmethod
    def on_asset_deleted(self, asset_id):
        """An asset has been deleted. Called whenever an asset has been removed and should no longer be considered by
        the follower.

        Note:
            This is **not** called if an asset has been deleted whilst the follower is not running.
        """
        raise NotImplementedError

    @abstractmethod
    def on_event(self, event):
        """A new event has been published for a particular asset.

        Args:
            event (AssetEvent): event instance

        Note:
            Does not include internal events apart from ``IntTwinEventInvalid`` and ``IntFollowerEventInvalid``
        """
        raise NotImplementedError

    def on_event_internal(self, event):
        """Override to handle internal events (see api.event.internal). This does **not** include internal events
        explicitly listed by on_event.
        """
        pass


class NamedEventMixin:
    """Routes on_event calls to functions named ``do_<EVENT_TYPE_LOWERCASE>`` (ignoring events for which no function has
    been defined.

    Note:
        With this mixin included, on_event is overridden. If one is interested in handling (almost) all events the same
        way, this mixin might not be applicable.

    Example:
        For an event of type *AssetEvent* the method definition (can also be class/static) would be::

            def on_assetevent(self, event)
    """

    # Override for FollowerCallbacks
    def on_event(self, event):
        # Note: Failure will be logged in caller
        getattr(self, 'do_%s' % event.name().lower(), self.on_event_unmatched)(event)

    @abstractmethod
    def on_event_unmatched(self, event):
        """Called for any events which do not have a named "on_*" function. Should at least acknowledge events one is
        not interested in."""
        raise NotImplementedError


# Brief status of follower
FollowerStatus = namedtuple('FollowerStatus', 'running agent t2_enabled asset_count')
"""Follower status summary

Attributes:
    running (bool): follower has been started
    agent (AgentStatus): instance of AgentStatus
    t2_enabled (bool): whether T2 functionality is enabled in this follower
    asset_count (int): number of assets this follower is currently aware of
"""

# Id of asset, RemoteFeed (events) and RemoteControl (replay requests) instances
_KnownAsset = namedtuple('_KnownAsset', 'id_ event_feed replay_control t2_req_control')


class Follower:  # pylint: disable=too-many-instance-attributes
    """Provides asset and event notifications as well as event confirmation functionality."""

    def __init__(self, config, client, callbacks):
        """Instantiate follower. Use start() to actually begin asset discovery.

        Args:
            config (dict): Nested configuration mapping for follower
            client (Client): Agent to use for Iotic Space communication (instance of IoticAgent.IOT.Client). This client
                must be running by the time this class' start() method is called.
            callbacks (FollowerCallbacks): Instance of callback-implementing class
        """
        if not isinstance(config, Mapping):
            raise TypeError('config')
        if not isinstance(client, Client):
            raise TypeError('client')
        if not isinstance(callbacks, FollowerCallbacks):
            raise TypeError('callbacks')
        self.__config = config
        client.register_callback_deleted(self.__cb_iotic_deleted, serialised=False)
        self.__client = client
        self.__callbacks = callbacks
        # Thing through which live events are received and control to which replay events are sent
        self.__thing = None
        self.__replay_control = None
        self.__setup_replay_and_tracker(config)

        # Holds all event types available for publishing
        self.__registry = load_event_registry(NestedConfig.get(
            config, 'asset.event.modules', required=False, default=(),
            check=lambda x: NestedConfig.Check.seq_non_empty_str(x, zero_items_allowed=True)
        ))
        # Mapping of asset id to _KnownAsset instance. WARNING: Currently only updated in background thread so no
        # locking required as long as all iterable access is materialised in advance.
        self.__assets = {}
        # Buffers events such that they can be passed on in right order and without duplication
        self.__events = AssetEventSerialiser()
        # Pending deletions (via agent notifications) which should be applied to assets.
        self.__deleted = deque()
        with_t2 = NestedConfig.get(self.__config, 'asset.with_type2', required=False, default=False, check=bool)
        # For making (and receiving responses of) T2 requests. Stays unset unless T2 enabled, in which case it is set
        # to False until the handler has been initialised.
        self.__t2_handler = False if with_t2 else None

        self.__asset_watcher_thread = Thread(
            target=self.__asset_watcher_run,
            args=(DiscoveryConfig.from_config(self.__config, producer=False, with_t2=with_t2),),
            name='watcher', daemon=True
        )
        self.__pool = ScheduledPool(
            max_workers=NestedConfig.get(
                config, 'workers', required=False, default=2, check=lambda x: isinstance(x, int) and x > 0
            ),
            thread_name_prefix='fworker'
        )
        self.__end = Event()
        self.__end.set()

    def __setup_replay_and_tracker(self, config):
        """Configure event offset tracking & replay (if enabled)"""
        if NestedConfig.get(config, 'asset.event.replay.enabled', required=False, default=True, check=bool):
            self.__replay_enabled = True
            # Timeout for replay requests
            self.__replay_timeout = NestedConfig.get(
                config, 'asset.event.replay.timeout', required=False, default=10,
                check=lambda x: NestedConfig.Check.positive_int(x) and x >= 10
            )
            # Keeps track of asset event offsets as confirmed via ack_event
            self.__tracker = get_tracker(config)
        else:
            log.info('Event replay disabled, tracker config will be ignored')
            self.__replay_enabled = False
            self.__replay_timeout = 0
            self.__tracker = get_tracker({}, warn_no_config=False)

    def start(self):
        """Starts the follower. Other public methods herein must not be called beforehand. Should be called after
        starting Iotic agent. Alternatively use with keyword on the instance."""
        log.debug('Starting')
        self.__end.clear()
        self.__create_thing()
        if self.__t2_handler is False:
            self.__t2_handler = T2Handler(self.__thing)
        self.__tracker.start()
        self.__pool.start()
        self.__asset_watcher_thread.start()

    def stop(self, timeout=10):
        """Stops the follower. Should be called before shutting down the Iotic agent."""
        log.debug('Stopping')
        self.__end.set()
        self.__asset_watcher_thread.join(timeout=timeout)
        if self.__asset_watcher_thread.is_alive():
            log.warning('Asset watcher thread still running')
        self.__pool.stop()
        self.__tracker.stop()
        if self.__t2_handler:
            self.__t2_handler = False

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop()

    @property
    def status(self):
        """Status summary as :py:class:`FollowerStatus` instance"""
        return FollowerStatus(
            running=(not self.__end.is_set()),
            agent=get_agent_status(self.__client),
            t2_enabled=(self.__t2_handler is not None),
            asset_count=len(self.__assets)
        )

    @property
    def assets(self):
        """Sequence of assets (snapshot) known to follower internally. ``on_asset_*`` callbacks should be used to
        determine what assets exist rather than polling this."""
        return tuple(self.__assets)

    @property
    def _own_thing(self):
        """Iotic Thing which follower uses to receive events with. WARNING: This is exposed for extending functionality
        only and care must be taken when modifying it so as to not clash with existing settings, points and metadata."""
        return self.__thing

    def ack_event(self, event):
        """Acknowledge that an event has been handled. Any events with a smaller offset are also implied to have been
        handled. Unknown assets events will be ignored.

        Args:
            event (AssetEvent): Instance of an event

        Raises:
            TypeError: If the event is invalid
        """
        if not isinstance(event, AssetEvent):
            raise TypeError('event')
        if event.offset < 0:
            raise ValueError('offset not set')
        if event.asset not in self.__assets:
            return
        # Want events larger than previous, hence adding one
        self.__tracker.set_offset(event.asset, event.offset + 1)

    def t2_request(self, asset_id, type_, data=None, timeout=10, chunk_timeout=10):
        """Makes a type 2 request for the given asset.

        Args:
            asset_id (str): asset to which request applies
            type_ (str): type of request
            data (bytes, optional): any additional arguments specific to the request
            timeout (int or float, optional): how long to wait (in seconds, fractional) before receive first response
                chunk
            chunk_timeout (int or float, optional): how long to wait (in seconds, fractional) before next expected (but
                not first) chunk arrives

        Yields:
            Tuples of response mime type and raw data (bytes)

        Raises:
            AssetUnknown: if the asset is not known to this follower
            TypeError: if type is invalid
            ValueError: if data or timeout is invalid
            ShutdownRequested: If shutdown is requested before this request has completed
            T2ResponseException: if request failed to due a provider-related issue
            T2Timeout: if the request could not be completed within the specified timeout (including lack of Iotic Space
                connection)
            T2Unavailable: if type 2 functionality has not been enabled for this follower
            NotConnected: There currently is no Iotic Space connection to service the request
        """
        if not self.__t2_handler:
            raise NotConnected if self.__t2_handler is False else T2Unavailable

        try:
            t2_req_control = self.__assets[asset_id].t2_req_control
        except KeyError as ex:
            raise AssetUnknown(asset_id) from ex

        yield from self.__t2_handler.t2_request(asset_id, t2_req_control, type_, data, timeout, chunk_timeout)

    def __create_thing(self):
        """Create thing from which to subscribe as well as control to receive replayed events"""
        client = self.__client
        self.__thing = thing = client.create_thing(
            NestedConfig.get(self.__config, 'thing.lid', check=NestedConfig.Check.non_empty_str)
        )
        if thing.agent_id != client.agent_id:
            log.warning('Reassigning %s from %s', thing.lid, thing.agent_id)
            thing.reassign(client.agent_id)

        thing_meta = ThingMeta.from_config(self.__config, 'thing', tag_default=())

        if thing_meta.tags:
            thing.create_tag(thing_meta.tags)
        if thing_meta.label or thing_meta.description:
            with thing.get_meta() as meta:
                if thing_meta.label:
                    meta.set_label(thing_meta.label)
                if thing_meta.description:
                    meta.set_description(thing_meta.description)

        self.__replay_control = replay = thing.create_control('replay_receiver', callback=self.__cb_replay_control)
        for value in ES_VALUES_FOR_REPLAY:
            replay.create_value(value.label, vtype=value.type_, unit=value.unit, description=value.description)

    def __asset_watcher_run(self, discovery_config):
        """Responsible for periodically updating known asset list and subscription management"""
        log.info('Started')
        try:
            self.__watcher_loop(discovery_config)
        except:
            log.critical('Watcher loop failure', exc_info=True)
        log.info('Finished')

    def __cb_iotic_deleted(self, args):
        if args[M_RESOURCE] == R_SUB:
            subs = set(args['ids'])
            for asset in tuple(self.__assets.values()):
                if asset.event_feed.subid in subs or asset.replay_control.subid in subs:
                    log.debug('Asset %s to be removed', asset.id_)
                    self.__deleted.append(asset.id_)
                    subs.discard(asset.event_feed.subid)
                    subs.discard(asset.replay_control.subid)
                    if not subs:
                        break

    def __watcher_loop(self, discovery_config):
        end = self.__end

        while not end.is_set():
            start = monotonic()
            log.debug('Performing asset search')

            try:
                found = self.__found_assets(discovery_config)
                # Removing first since might attempt re-adding (for notified unsubscriptions)
                self.__update_assets_remove(found)
                self.__update_assets_add(found)
            except LinkShutdownException:
                # Shutdown requested whilst request pending
                return
            except:
                # not important on shutdown (client might already be stopped)
                if not end.is_set():
                    log.error('Discovery/update failure', exc_info=DEBUG_ENABLED)

            log.debug('Asset update complete')
            end.wait(max(0, discovery_config.interval - (monotonic() - start)))

    def __update_assets_remove(self, found):
        """Remove any assets which are not in found list as well as actioning any space-notified deletions."""
        update_assets_remove_one = self.__update_assets_remove_one
        submit_with_future = self.__pool.submit_with_future

        # Wait for all additions to finish as do not want to overlap long running addition with next discovery loop
        for future in as_completed(
                submit_with_future(update_assets_remove_one, id_)
                # Remove unknown ones (and any which have been notified as deleted)
                for id_ in chain(
                    # (False positive) pylint: disable=bad-continuation
                    tuple(self.__assets.keys()) - found.keys(),
                    # Since not dequeued anywhere else, safe to pop by length. Use set as could contain duplicates since
                    # notifications can be about both replay control and event feed
                    {self.__deleted.popleft() for _ in range(len(self.__deleted))}
                )
        ):
            ex = future.exception()
            if ex:
                log.error('Unexpected failure whilst removing asset', exc_info=(ex if DEBUG_ENABLED else None))

    def __update_assets_add(self, found):
        """Add any assets which have been newly found"""
        update_asset_add_one = self.__update_asset_add_one
        submit_with_future = self.__pool.submit_with_future

        # Wait for all additions to finish as do not want to overlap long running addition with next discovery loop
        for future in as_completed(
                # found[id_] => replay_guid, t2_req_guid, event_guid
                submit_with_future(update_asset_add_one, id_, *found[id_])
                for id_ in tuple(found.keys() - self.__assets.keys())
        ):
            ex = future.exception()
            if ex:
                log.error('Unexpected failure whilst adding asset', exc_info=(ex if DEBUG_ENABLED else None))

    def __update_assets_remove_one(self, id_):
        """Blindly removes the given asset, if it is known locally. For use with async pool. Should NOT be called
        multiple times in parallel for the same asset id_.
        """
        log.info('Removing asset %s', id_)
        # Since dealing with more than one subscription, remove local asset reference at this stage so can ignore
        # second sub deletion (in __cb_iotic_deleted callback). Otherwise could have endless loop of a) asset sub
        # deleted, b) asset removed (generates another sub deleted callback), c) asset re-subscribed, d) asset
        # deleted again due to (b).
        try:
            asset = self.__assets.pop(id_)
        except KeyError:
            # Delete-notified asset already removed previously
            return

        thing = self.__thing
        success = True

        for func, arg in (
                (thing.unattach, asset.t2_req_control),
                (thing.unattach, asset.replay_control),
                (thing.unfollow, asset.event_feed),
                (self.__tracker.clear_for, id_),
                (self.__events.clear, id_)
        ):
            # Some might not apply, e.g. t2 request control
            if not arg:
                continue
            try:
                func(arg)
            except IOTUnknown:
                # E.g. might have been deleted remotely in mean time
                pass
            except LinkShutdownException:
                # Shutdown requested whilst request pending
                return
            except:
                log.error('Failed to remove asset %s, will attempt again on next update', id_, exc_info=DEBUG_ENABLED)
                self.__deleted.append(id_)
                success = False
                break

        if success:
            self.__do_callback('on_asset_deleted', id_)
        else:
            # Retain reference so can attempt removal later
            self.__assets[id_] = asset

    def __update_asset_add_one(self, id_, replay_guid, t2_req_guid, event_guid):
        """Blindly adds the given asset, i.e. asset is expected to be unknown. For use with async pool. Should NOT be
        called multiple times in parallel for the same asset id_.
        """
        # Mapping to point guid & bool indicating whether Control (True) or Feed (False)
        points = {'replay': (replay_guid, None), 'event': (event_guid, self.__cb_event_feed)}
        if self.__t2_handler:
            points['t2_req'] = (t2_req_guid, None)
        # Mapping to remote feed/control, keyed same as points dict above
        remotes = {}

        next_offset = self.__tracker.get_offset(id_)
        if self.__replay_enabled:
            # Not clearing on failure later since if initialised already, subsequent calls are no-op
            self.__events.initialise(id_, next_offset)

        for name, (guid, is_control) in points.items():
            remote = self.__follow_or_attach(id_, guid, feed_callback=is_control)
            if remote is None:
                return
            if not remote:
                break
            remotes[name] = remote

        if len(remotes) < len(points):
            log.debug('Failed to fully connect to asset %s, unsubscribing', id_)
            for remote in remotes.values():
                if self.__unfollow_or_unattach(id_, remote) is None:
                    # shutdown requested
                    return
            return

        self.__assets[id_] = _KnownAsset(id_, remotes['event'], remotes['replay'], remotes.get('t2_req'))
        log.info('Added asset %s', id_)
        self.__do_callback('on_asset_created', id_)
        if self.__replay_enabled:
            self.__pool.submit(self.__request_replay, id_, next_offset)

    def __follow_or_attach(self, asset_id, point_guid, feed_callback=None):
        """Tries to attach to control or follow a feed (if feed_callback is set). Returns remote control on success,
        False on failure and None if shutdown requested.
        """
        try:
            if feed_callback:
                return self.__thing.follow(point_guid, callback=partial(feed_callback, asset_id))
            return self.__thing.attach(point_guid)
        except IOTUnknown:
            # Might have been deleted in mean time
            pass
        except LinkShutdownException:
            # Shutdown requested whilst request pending
            return None
        except IOTAccessDenied:
            # TODO - ignore assets after this?
            log.warning('Asset %s subscription (to %s) denied', asset_id, point_guid)
        except:
            log.error(
                'Failed to attach/follow to asset %s (%s), will attempt again on next update', asset_id, point_guid,
                exc_info=log.isEnabledFor(logging.DEBUG)
            )
        return False

    def __unfollow_or_unattach(self, asset_id, remote):
        """Tries to unattach control / unfollow feed. remote is expected to be RemotePoint instance. Returns True on
        success, False on failure and None if shutdown requested.
        """
        try:
            (self.__thing.unattach if isinstance(remote, RemoteControl) else self.__thing.unfollow)(remote)
        except IOTUnknown:
            # Might have been deleted in mean time return False
            pass
        except LinkShutdownException:
            # Shutdown requested whilst request pending
            return None
        except:
            log.warning(
                'Failed to un-attach/follow asset %s (%s)', asset_id, remote.guid,
                exc_info=log.isEnabledFor(logging.DEBUG)
            )
            return False
        return True

    @in_own_thread_single
    def __do_callback(self, name, *args, **kwargs):
        try:
            getattr(self.__callbacks, name)(*args, **kwargs)
        except:
            log.error('%s(*%s, **%s) failed', name, args, kwargs, exc_info=DEBUG_ENABLED)

    def __found_assets(self, discovery_config):
        """Performs search and returns mapping of asset id to tuple of control (replay) & feed (event) guids for
        matching ones.
        """
        submit_with_future = self.__pool.submit_with_future
        get_consume_points = partial(
            get_asset_points_for_thing, self.__client, DescribeScope(discovery_config.scope.value),
            discovery_config.meta, require_feed=True, require_t2=bool(self.__t2_handler)
        )

        return {
            asset_id: (replay_guid, t2_req_guid, feed_guid)
            for asset_id, replay_guid, t2_req_guid, feed_guid in filter(
                # get_consume_points will return None result when not a valid asset - using filter() to ignore
                None,
                # Note: Future.result() will raise Exception on failure which is handled higher up
                map(lambda x: x.result(), as_completed(
                    # Determine whether valid assets and get relevant details
                    submit_with_future(get_consume_points, guid)
                    # Retrieve potential asset things
                    for guid in search_iter(
                        # Current 'reduced' search type is limited to 200 results
                        self.__client, text=discovery_config.text, scope=discovery_config.scope, reduced=True, limit=200
                    )
                ))
            )
        }

    def __request_replay(self, asset_id, offset):
        try:
            asset = self.__assets[asset_id]
        except KeyError:
            log.debug('Ignoring replay request, asset %s no longer known', asset_id)

        log.debug('Preparing replay for %s @ %d', asset_id, offset)
        template = get_es_template_for_replay_req()
        template.values.seq = offset
        template.values.cb_guid = self.__replay_control.guid

        try:
            result = asset.replay_control.tell(template, timeout=self.__replay_timeout)
        except (IOTUnknown, LinkShutdownException):
            return
        except:
            log.warning('Replay request for %s failed, will retry', asset_id, exc_info=DEBUG_ENABLED)
        else:
            if result is True:
                log.info('Replay start confirmed for %s @ %d', asset_id, offset)
                self.__do_callback('on_event_internal', IntFollowerStartReplay.for_asset(asset_id, offset))
                return
            log.warning('Replay request for %s failed (%s), will retry', asset_id, result)

        self.__pool.submit_delayed(5, self.__request_replay, asset_id, offset)

    __internal_events_for_on_event = frozenset(cls.name() for cls in (IntTwinEventInvalid, IntFollowerEventInvalid))

    def __handle_internal_event(self, event):
        """Returns True if this event has been handled and should not be considered for normal event tracker."""
        name = event.name()
        if name == IoticInternalTwinEvent.EOF_REPLAY:
            log.info('Replay finished for %s @ %d', event.asset, event.offset)
        elif name == IoticInternalTwinEvent.EOF_SHUTDOWN:
            log.info('Replay ended for %s @ %d due to shutdown', event.asset, event.offset)
            # Attempt to resume replay. Using offset as known by serialiser since tracker offsets might be lagging
            # behind (due to relying on API user to ACK).
            try:
                next_offset = self.__events.get_next_offset_for(event.asset)
            except SerialiserAssetUnknown:
                return False
            self.__pool.submit_delayed(5, self.__request_replay, event.asset, next_offset)
        elif name == IoticInternalTwinEvent.EVENT_INVALID:
            log.warning('Unparsable event in stream for %s @ %d', event.asset, event.offset)

        # Most internal events go to separate callback
        if name not in self.__internal_events_for_on_event:
            self.__do_callback('on_event_internal', event)
            return True

        return False

    def __decode_event(self, template, log_id, asset_id, systime=None):
        """Returns decoded event or internal one identifying failure if possible, None otherwise. log_id is a string to
        prefix logging messages with since this method is used both for feed and replay event decoding.
        """
        event = None
        event_ex = None

        try:
            event = self.__registry.decode_from(template, asset_id=asset_id, systime=systime)
        except ValueError:
            # internal failure - do not propagate
            log.error('%s - One or more parameters invalid for %s', log_id, asset_id, exc_info=DEBUG_ENABLED)
        except UnknownEvent as ex:
            log.error('%s - Unknown event %s for %s', log_id, ex.event_type, asset_id)
            event_ex = ex
        except UnknownVersion as ex:
            log.error('%s - Unknown version of %s (v%d) for %s', log_id, ex.event_type, ex.version, asset_id)
            event_ex = ex
        except EncodeDecodeError as ex:
            log.error(
                '%s - Event data decoding failed %s (v%d) for %s', log_id, ex.event_type, ex.version, asset_id,
                exc_info=DEBUG_ENABLED
            )
            event_ex = ex
        except ValidationError as ex:
            log.error(
                '%s - Event data validation failed %s (v%d) for %s', log_id, ex.event_type, ex.version, asset_id,
                exc_info=DEBUG_ENABLED
            )
            event_ex = ex
        except:
            log.exception('Unexpected event decode failure')

        # Internal events are still propagated, but additional actions might required here first
        if event and event.source == SOURCE_IOTIC_INTERNAL:
            if self.__handle_internal_event(event):
                return None

        return (
            IntFollowerEventInvalid._from_registry_exception(event_ex, asset_id, template, systime) if event_ex else
            event
        )

    def __add_event_and_callback(self, event):
        """Add parsed event for an asset and callback if at least one expected (in sequence) event is available"""
        try:
            if self.__events.add(event):
                log.debug('At least one event ready (via feed) for %s', event.asset)
                for ready in self.__events.retrieve_for(event.asset):
                    self.__do_callback('on_event', ready)
        except SerialiserAssetUnknown:
            # With replay disabled, event serialisation can only be initialised on receiving the first live event for a
            # particular asset.
            if not self.__replay_enabled:
                log.debug('Initialising event serialiser for asset %s from live event @%d', event.asset, event.offset)
                self.__events.initialise(event.asset, event.offset)
                self.__add_event_and_callback(event)
            # With replay enabled: Asset removed before adding or rerieving events

    def __cb_event_feed(self, asset_id, args):
        log.debug('Live event for %s: %s', asset_id, args)
        if asset_id not in self.__assets:
            return

        try:
            template = get_es_template_for_feed(data=args['data'])
        except:
            # Note: Cannot acknowledge since not decoded so ignoring. If this was supposed to be a real event, this
            # asset's events might now be stuck due to a missing event which will never arrive.
            log.error('Unparsable event feed share from %s', asset_id, exc_info=DEBUG_ENABLED)
            return

        event = self.__decode_event(template, 'Feed', asset_id, systime=args['time'])
        if event:
            self.__add_event_and_callback(event)

    def __cb_replay_control(self, args):
        log.debug('Replay: %s', args)

        try:
            template = get_es_template_for_replay(data=args['data'])
        except:
            # Note: Cannot acknowledge since not decoded. Problem: If this was supposed to be a real event, this asset's
            # events might now be stuck due to a missing event which will never arrive.
            log.error('Unparsable replay', exc_info=DEBUG_ENABLED)
            return

        if template.values.asset not in self.__assets:
            return

        event = self.__decode_event(
            template, 'Replay', template.values.asset, systime=datetime.utcfromtimestamp(template.values.systime)
        )

        if event:
            self.__add_event_and_callback(event)
