# Copyright (c) 2019 Iotic Labs Ltd. All rights reserved.

import re
import logging
from datetime import datetime, timezone
from collections import namedtuple
from collections.abc import Mapping, Sequence
from copy import deepcopy
from io import BytesIO

from fastavro import (
    parse_schema as avro_parse_schema, schemaless_writer as avro_schemaless_writer,
    schemaless_reader as avro_schemaless_reader
)

from ioticlabs.dt.common.values.es import BasicPointDataObject

from .util import module_event_class_iterator
from .base import AssetEvent
from .internal import _InternalEvent
from .exceptions import UnknownEvent, UnknownVersion, EncodeDecodeError, ValidationError

log = logging.getLogger(__name__)


def load_event_registry(modules):
    """Loads event types from the given sequence of modules into a registry as well as populating it with built-in ones.
    Returns the registry."""
    registry = AssetEventRegistry()
    registry.populate_internal()
    count = registry.populate_from_modules(modules)
    if modules and not count:
        raise ValueError('No event classes found in modules')
    log.info('Loaded %d event types', count)
    return registry


# Used by AssetEventRegistry to store registered events
_EventDefinition = namedtuple('_EventDefinition', 'name cls, versions')


class AssetEventRegistry:

    __valid_name = re.compile('^([A-Z][a-z0-9]+)+$', re.A)

    def __init__(self):
        self.__types = {}

    def register(self, cls):
        """Adds a new event class (AssetEvent) to the registry. Validates the implementating class and caches a
        representation thereof internally.

        cls - an AssetEvent implementation

        Raises:
            TypeError - cls is not an AssetEvent subclass
            ValueError - cls is invalid in some way

        Returns: True if the type was added, False if this particular class has already been added previously
        """
        name, versions = self.__validate_type(cls)

        if name in self.__types:
            return False

        # Accumulate last schema for each version. All prior schemas are merely there for reference by final one.
        parsed_versions = {}
        # Must have consecutive versions
        last = 0

        for version in sorted(versions):
            if version != last + 1:
                raise ValueError('Missing version: %d' % (last + 1))
            last += 1
            parsed_versions[version] = self.__parse_version(name, version, versions[version])

        self.__types[name] = _EventDefinition(name=name, cls=cls, versions=parsed_versions)

        return True

    @classmethod
    def __validate_type(cls, type_):
        """Returns tuple of event name and versions mapping"""
        if not issubclass(type_, AssetEvent):
            raise TypeError('Not a subclass of AssetEvent')

        try:
            # Will raise e.g. RuntimeError if not all abstract methods implemented
            type_('asset')
        except Exception as ex:
            raise ValueError('Event class not fully implemented') from ex

        name = type_.name()
        if not cls.__valid_name.match(name):
            raise ValueError('Event name must be ASCII camel case (length > 1)')

        # Note: Instantiating of class might have already called _default_version / _known_versions indirectly but do
        # check explicitly anyway.
        try:
            default = type_._default_version()
        except Exception as ex:
            raise ValueError('Default version method excepts') from ex
        if not (isinstance(default, int) and default > 0):
            raise ValueError('Invalid default version')

        try:
            versions = type_._known_versions()
        except Exception as ex:
            raise ValueError('Known versions method excepts') from ex
        if not isinstance(versions, Mapping):
            raise ValueError('Known versions not a mapping')
        if not all(isinstance(version, int) and version > 0 for version in versions):
            raise ValueError('Versions must be positive integers')
        if default not in versions:
            raise ValueError('Default %d not in versions' % default)

        return name, versions

    @classmethod
    def __parse_version(cls, event_name, version, schemas):
        if schemas is None:
            return None

        # Handle single schema case in same way as for multiple
        if isinstance(schemas, dict) or not isinstance(schemas, Sequence):
            schemas = (schemas,)

        # All but last schema used for registering sub-types with avro library. Only need to remember final one.
        final_schema = None

        for i, schema in enumerate(schemas, 1):
            # Require dict since fastavro expects it (rather than Mapping)
            if not isinstance(schema, dict):
                if len(schemas) == 1:
                    raise ValueError('Invalid version %d: Must be dict schema(s) or None' % version)
                else:
                    raise ValueError('Schema #%d for version %d not a dict or None' % (i, version))

            try:
                final_schema = avro_parse_schema(cls.__get_prefixed_schema(event_name, schema))
            except Exception as ex:
                raise ValueError('Schema #%d for version %d invalid' % (i, version)) from ex

        if not final_schema:
            raise ValueError('Invalid version %d: Empty schema sequence specified' % version)

        return final_schema

    @classmethod
    def __get_prefixed_schema(cls, prefix, schema):
        """Return copy of schema, with namespaces and absolute names & aliases prefixed.

        prefix - string without trailing '.'
        schema - a mapping

        Raises:
            ValueError - schema is deemed to not be valid (e.g. duplicate field names in record).
        """
        # Don't modify original
        schema = deepcopy(schema)
        # Preserve here so can remember whether was non-empty/set so can add default schema afterwards
        namespace = schema.get('namespace')
        cls.__prefix_mapping(prefix + '.', schema)
        # __prefix_mapping will already have updated it unless was empty/unset
        if not namespace:
            schema['namespace'] = prefix
        return schema

    @classmethod
    def __prefix_mapping(cls, prefix, mapping):
        """Assumes passed mapping is a Mapping. Used by __get_prefixed_schema"""
        __prefix_mapping = cls.__prefix_mapping

        for key, value in list(mapping.items()):
            # Items can either be reference or sub-section, hence also check for str
            if key in ('name', 'items') and isinstance(value, str):
                value = str(value)
                if '.' in value:
                    mapping[key] = prefix + value

            elif key == 'aliases':
                if isinstance(value, str):
                    value = (value,)
                elif not isinstance(value, Sequence):
                    value = (str(value),)
                mapping[key] = [(prefix + str(alias) if '.' in alias else alias) for alias in map(str, value)]

            elif key == 'namespace':
                if value:
                    mapping[key] = prefix + str(value)
                # Ignore empty / False-evaluating namespaces
                else:
                    del mapping[key]

            elif isinstance(value, Mapping):
                __prefix_mapping(prefix, value)

            elif isinstance(value, Sequence) and not isinstance(value, str):
                for sub_value in value:
                    if isinstance(sub_value, Mapping):
                        __prefix_mapping(prefix, sub_value)

                # Check for duplicated fields
                if mapping.get('type') == 'record':
                    fields = mapping.get('fields', ())
                    if len(fields) != len({field.get('name', i) for i, field in enumerate(fields)}):
                        raise ValueError('Record "%s" contains duplicate fields' % mapping.get('name', ''))

    def __get_name_and_schema(self, event, allow_internal):
        """Returns tuple of name and applicable schema. Raises appropratiate exceptions as expected by encode method."""
        if not isinstance(event, AssetEvent):
            raise TypeError('event')
        name = event.name()

        if not allow_internal and isinstance(event, _InternalEvent):
            raise UnknownEvent(name)

        try:
            definition = self.__types[name]
        except KeyError as ex:
            raise UnknownEvent(name) from ex

        try:
            return name, definition.versions[event.version]
        except KeyError as ex:
            raise UnknownVersion(name, event.version)

    def encode_into(self, event, template, allow_internal=False):
        """Encode the given event, outputting event-data related fields (type, version, time & data) into the referenced
        template.

        event - the AssetEvent instance
        template - BasicPointDataObject instance to encode into. Expected values must match ES_VALUES_WITH_TIME
            (see ...common.values)
        allow_internal - whether to allow internal events also

        Raises:
            TypeError - event is not an AssetEvent (or is internal) or template not a BasicPointDataObject
            AttributeError - template does not have the expected values to encode into
            UnknownEvent - event is not registered
            UnknownVersion - event version not known for registered event
            EncodeDecodeError - extra data cannot be encoded
            ValidationError - additional type data validation failed
        """
        if not isinstance(template, BasicPointDataObject):
            raise TypeError('template')

        name, schema = self.__get_name_and_schema(event, allow_internal)

        values = template.values
        values.type = name
        values.version = event.version
        # datetime.timestamp() assumes local time for naive instances, hence set tzinfo to force UTC. (Event instances
        # all have naive timestamps in UTC.)
        values.time = (event.time or datetime.utcnow()).replace(tzinfo=timezone.utc).timestamp()

        if schema is None:
            if event.data is not None:
                raise EncodeDecodeError(name, event.version, 'No schema, but extra data specified')
            values.data = None
        else:
            output = BytesIO()
            try:
                avro_schemaless_writer(output, schema, event.data)
            except Exception as ex:
                raise EncodeDecodeError(name, event.version) from ex
            try:
                # Validating after encoding means structure of data is correct
                event._validate_data()
            except Exception as ex:
                raise ValidationError(name, event.version)

            values.data = output.getvalue()

    def __get_class_and_schema(self, name, version):
        """Returns tuple of class and applicable schema. Raises appropratiate exceptions as expected by decode method.
        """
        try:
            definition = self.__types[name]
        except KeyError as ex:
            raise UnknownEvent(name) from ex

        try:
            return definition.cls, definition.versions[version]
        except KeyError as ex:
            raise UnknownVersion(name, version)

    def decode_from(self, template, asset_id=None, systime=None):
        """Decode event from the given template, returning an AssetEvent instance

        template - BasicPointDataObject instance to decode from. Expected values must at least contain ES_VALUES
            (see ...common.values)
        asset_id - id of asset (str, optional). Used instead of "asset" value in template.
        systime - event storage/system time (datetime, optional).

        Raises:
            TypeError - template is not a BasicPointDataObject
            AttributeError - template does not have the expected values to decode from
            ValueError - additional parameters (or values in template) are not valid
            UnknownEvent - event is not registered
            UnknownVersion - event version not known for registered event
            EncodeDecodeError - extra data cannot be decoded
            ValidationError - additional type data validation failed
        """
        if not isinstance(template, BasicPointDataObject):
            raise TypeError('template')
        values = template.values
        try:
            time = datetime.utcfromtimestamp(values.time)
        except TypeError as ex:
            raise ValueError('event time invalid') from ex
        cls, schema = self.__get_class_and_schema(values.type, values.version)

        # Events with no extra data
        if schema is None:
            if values.data is not None:
                raise EncodeDecodeError(values.type, values.version, 'No schema, but extra data specified')
            return cls(
                asset=asset_id or values.asset,
                source=values.source,
                time=time,
                systime=systime,
                offset=values.seq,
                version=values.version
            )

        return self.__decode_event_with_data(cls, schema, asset_id, time, systime, values)

    @staticmethod
    def __decode_event_with_data(event_class, schema, asset_id, time, systime, values):
        if values.data is None:
            raise EncodeDecodeError(values.type, values.version, 'Schema, but no extra data specified')
        try:
            data = avro_schemaless_reader(BytesIO(values.data), schema)
        except Exception as ex:
            raise EncodeDecodeError(values.type, values.version) from ex

        # Will raise ValueError if any parameters invalid
        event = event_class(
            asset=asset_id or values.asset,
            source=values.source,
            time=time,
            systime=systime,
            offset=values.seq,
            version=values.version,
            data=data
        )
        try:
            event._validate_data()
        except Exception as ex:
            raise ValidationError(values.type, values.version)

        return event

    def populate_from_modules(self, modules):
        """Register any classes found within the given set of modules. Ignores internal events·

        modules - a sequence of full modules names, or single name

        Raises:
            TypeError - cls is not an AssetEvent subclass
            ValueError - cls is invalid in some way
            ImportError - one of the modules failed to import

        Returns: Total number of (unique) event types loaded which have not previously been registered

        """
        return self.__populate_from_modules(modules)

    def populate_internal(self, modules=()):
        """Load internal events from the given modules. If none are specified, defaults to internal sub-module."""
        if not modules:
            from . import internal
            modules = (internal,)
        return self.__populate_from_modules(modules, internal=True)

    def __populate_from_modules(self, modules, internal=False):
        register = self.register
        total = 0

        if isinstance(modules, str):
            modules = (modules,)

        def on_import_error(ex):
            raise ImportError from ex

        for module in modules:
            log.debug('Loading event types from module %s', module)
            for cls in module_event_class_iterator(module, internal=internal, on_import_error=on_import_error):
                if register(cls):
                    log.debug('Registered type %s', cls.name())
                    total += 1
                elif internal:
                    # Should not have multiple references for own event
                    raise ValueError('Duplicate internal event: %s' % cls.name())

        return total
