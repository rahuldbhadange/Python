# ioticlabs.dt.api

## event
Provides means to define and validate event definitions

## follower
API for creating a twin follower, i.e. to consume events.

## integrator
API for creating a twin integrator, i.e. for publishing events to twins.
