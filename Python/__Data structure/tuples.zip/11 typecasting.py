
#case 1: Converting List to tuple
x=[10,20,30,40,50]
print(x)
print(type(x))

y=tuple(x) 
print(y)
print(type(y))

#case 2: Converting Tuple to List
a=(10,20,30,40,50)
print(a)
print(type(a))

b=list(a) 
print(b)
print(type(b))

#case 3: Converting string to List
p="computer"
print(p)
print(type(p))

q=list(p) #
print(q)
print(type(q))

#case 4: Converting string to Tuple
m="computer"
print(m)
print(type(m))

n=tuple(m) #Converting string to tuple
print(n)
print(type(n))

'''#case 5: Converting int to List (can't be converted)
i=10
print(i)
print(type(i))

j=list(i) #Converting int to list ,int not allowed as parameter to list
print(j)
print(type(j)) '''

#but there is a alternate way to convert int to list
i=10
print(i)
print(type(i))

j=[i] 
print(j)
print(type(j))

#case 6: Converting string to int
k="10"
print(k)
print(type(k))

l=int(k) #Converting string to int
print(l)
print(type(l))

#case 7: Converting int to string
s=10
print(s)
print(type(s))

t=str(s) #Converting int to string
print(t)
print(type(t))

#case 8: Converting int to float
u=10
print(u)
print(type(u))

v=float(u) #Converting int to float
print(v)
print(type(v))

#case 9: Converting string to bool
w="True"
print(w)
print(type(w))

z=bool(w) #Converting string to bool
print(z)
print(type(z))

#case 10: Converting int to bool
c=1
print(c)
print(type(c))

d=bool(c) #Converting string to bool
print(d)
print(type(d))

#case 11: Converting  bool to int
e=True
print(e)
print(type(e))

f=int(e) #Converting bool to int
print(f)
print(type(f))




















