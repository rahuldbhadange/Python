#methods of tuple object

x=(10,20,30,40,10,20,10)
print(x)
print(x.count(10))
print(x.count(30))
print(x.count(50))
print(x.index(20))
print(x.index(20,2))
print(sorted(x))

print(reversed(sorted(x))) #result stored in another object

for p in reversed(sorted(x)): #printing the result of the object
    print(p)
