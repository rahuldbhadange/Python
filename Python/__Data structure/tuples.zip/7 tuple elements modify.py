#modifying tuple elements
#tuple is immutable object,but elements of tuple can be mutable or immutabe


#case 1 : ex for elements of tuple as mutable
#ex: taking lists as tuple elements where lists are mutable
x=([10,20,30],[40,50,60],[70,80,90]) 
print(x)
print(type(x))
print(len(x))

for p in x:
    print(p,type(p))
#Now modifying the list contents
x[0][1]="ganesh"
x[1][2]=55
x[2][2]=85
print(x)

#now modifying tuple elements
#x[0]="hello"
#x[1]=[35,45,55] #not possible bcoz tuple eement doesnt support assignment
#print(x)
#x[1]=(35,45,55) #changing or modifying list to tuple, which is not allowed
                #bcoz tuple is a immutable object

#x[2]=3.5
#case 2:ex for elements of tuple as immutable
x=(10,20,30,40,50)
print(x)
print(type(x))  
print(len(x))
#we cannot modify tuple elements
#x[2]=70
