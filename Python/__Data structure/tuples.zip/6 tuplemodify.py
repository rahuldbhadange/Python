#we cannot modify the content of tuple elements
x=(10,20,30,40,50)
x[1]=60 # we cannot modify tuple elements bcoz tuple is immutable
print(x)
