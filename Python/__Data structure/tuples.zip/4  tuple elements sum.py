#computing sum of tuple elements using for and while

x=(10,20,30,40,50)

# using for-loop
sum=0
for p in x:
    sum=sum+p
print("sum=",sum)


#using while loop

i=0
sum=0
while(i<len(x)):
    sum=sum+x[i]
    i=i+1
print("sum=",sum)
    
