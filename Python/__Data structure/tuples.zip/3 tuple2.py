#Accessing tuple elements 

x=(10,20,30,40,50)
print(x)
print(len(x))
print(x[0])
print(x[-1])
print(x[2:])
print(x[1:3])
print(x[-4:-1])
print(x[4:1])
print(x[-1:-4])
print(20 in x)
print(60 in x)
