#tuple as list element

x=[[10,20,30],[40,50,60],(70,80,90)] #3 elements of list,2 are lists and 1 is tuple
print(x)
print(type(x))
print(len(x))
for p in x:
    print(p,type(p))
#x[2][2]=85  #tuple element cant be modified 
x[2]=4.5    #list can be modified
#Now changing inner lists into tuple and boolean datatypes,here list allows these changes
x[0]=(1,2,3) # changing list to tuple
x[1]=True   #changing list to boolean
x[2]="hello"
print("after modification the list is",x)
print("printing each element of list")
for p in x:
    print(p,type(p))  #printing each element of list
    
