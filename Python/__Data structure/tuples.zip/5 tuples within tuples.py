# tuples within tuple
x=((10,20,30),(40,50,60),(70,80,90))

print(x)
print(type(x))
print(len(x))

print(x[0],type(x[0])) # printing 1st tuple 
print(x[1],type(x[1])) #printing 2nd tuple 
print(x[2],type(x[2])) #printing 3rd tuple 

#printing each tuple using for loop

for p in x:
      print(p,type(p))

#printing each element of sub tuples
for p in x:
      for q in p:
          print(q,type(q))
          
