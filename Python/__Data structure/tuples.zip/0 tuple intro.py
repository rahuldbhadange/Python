Tuple:Tuple is a collection datatype which holds group of values

Properties of Tuple:

1.Tuple represented by parenthesis ( )
2.Tuple allows homogeneous elements.  ex;  x=(10,20,30,40,50)
3.Tuple allows heterogeneous elements. ex: x=(50,6.1,True,"hello")
4.Tuple allows duplicate elements      ex: x=(10,20,30,10,20,40)          
5.In Tuple, insertion order is  preserved,the order in which the elements are
  inserted and the order in which they are stored are same.
6.Every element of tuple is identified by a unique index. 
  tuple supports positive and negative index.
  positive index starts from leftside to right side starts with 0
  negative index starts from rightside to left side starts with -1
   ex: x=(10,20,30,40,50)
         x[0]=10          x[4]=50   #positive indexes
         x[-1]=50         x[-3]=30  #negative indexes
         x[2:]=(30,40,50) x[1:4]=(20,30,40)   x[-4:-1]=(20,30,40) #slice operator
         x[4:1]=()      x[-1:-4]=()
7.Tuple is a immutable object, but elements of tuple can be either mutable or immutable.
8.Tuple can be created directly by using () or by using tuple() function

