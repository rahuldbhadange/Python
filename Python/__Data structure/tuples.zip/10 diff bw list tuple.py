#Difference between List and tuple
           List                                   Tuple
1.List objects are mutable objects    1.Tuple objects are immutable objects.
2.List elements can be mutable or     2.Tuple elements can be mutable or 
  immutable                             immutable
3.List objects cannot be used as key  3.Tuple object can be used as key in 
  in dictionaries                      dictionaries only when the tuple elements
                                       are immutable.
4.for insertion,deletion,updation     4.For retrieval operations,Tuple is recommended
  operations,List is recommended.
5.when iterations are applied on      5.when iterations are applied on Tuple,
  List,it takes more time               it takes less time.
