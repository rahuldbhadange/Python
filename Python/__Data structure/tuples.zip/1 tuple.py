#program illustrating tuple
x=(10,20,30,40) #creating tuple using parenthesis () ,homogeneous elements
print(x)
print(type(x))


y=(501,6.1,True,"hello")  #heterogeneous elements
print(y)
print(type(y))


z=100,200,300 # tuple can be created without ()
print(z)
print(type(z))


p=tuple()  # creating a empty tuple
print(p)
print(type(p))
print(len(p))


q=tuple("hello") # creating tuple with some data,here tuple takes only 1 parameter
print(q)    #that parameter can be string or iterable types like list etc
print(type(q))
print(len(q))

r=tuple([10,20,30]) 
print(r)    
print(type(r))
print(len(r))

#functions applied on tuple
print(len(x)) #displays length of tuple x
print(sum(x))
print(max(x)) #diplays max element of tuple x
print(min(x)) #displays min element of tuple x
print(sorted(x))

